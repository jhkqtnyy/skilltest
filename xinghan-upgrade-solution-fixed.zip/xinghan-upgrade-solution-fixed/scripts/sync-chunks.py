#!/usr/bin/env python3
"""
sync-chunks.py — Knowledge-base chunk synchroniser

Scans all Markdown files under ``knowledge-base/references``, splits each file into
chunks at h2/h3/h4 heading boundaries, computes a SHA-256 hash for every chunk,
and writes individual JSON chunk files plus a ``chunk-index.json`` manifest.

Modes
-----
full   – delete all existing chunks and rebuild from scratch.
incr   – only (re)write chunks whose content changed and remove stale ones.
status – print counts and disk usage without writing anything.

Exit codes
----------
0  – success
1  – runtime / I/O error
2  – invalid CLI arguments
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
KB_ROOT = Path(__file__).parent.parent / "knowledge-base"
DOCS_DIR = KB_ROOT / "references"
CHUNKS_DIR = KB_ROOT / "chunks"
CHUNK_INDEX = CHUNKS_DIR / "chunk-index.json"

MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MiB – skip larger files
HEADING_RE = re.compile(r"^(#{2,4})\s+(.+)$", re.MULTILINE)
FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)

# Rough tokenisation heuristic used for cost/usage estimation.
# GPT-family tokenisers average ~1 token per 1.5 Latin chars and ~1 token
# per ~1.67 CJK chars.  0.6 * len(text) is a cheap but decent compromise.
TOKEN_ESTIMATE_FACTOR = 0.6


def _error(msg: str) -> None:
    print(f"[ERROR] {msg}", file=sys.stderr)


def _warning(msg: str) -> None:
    print(f"[WARN] {msg}", file=sys.stderr)


# ---------------------------------------------------------------------------
# Front-matter helpers
# ---------------------------------------------------------------------------
def extract_frontmatter(text: str) -> Tuple[str, str]:
    """Return (frontmatter_yaml, body).  Front-matter must start at byte 0."""
    m = FRONTMATTER_RE.match(text)
    if m:
        return m.group(1), text[m.end():]
    return "", text


def parse_frontmatter(yaml_text: str) -> Dict[str, Any]:
    """Naïve YAML parser sufficient for simple key:value front-matter."""
    meta: Dict[str, Any] = {}
    for line in yaml_text.splitlines():
        if ":" not in line:
            continue
        key, val = line.split(":", 1)
        meta[key.strip()] = val.strip().strip('"').strip("'")
    return meta


# ---------------------------------------------------------------------------
# Chunking logic
# ---------------------------------------------------------------------------
def split_by_headings(text: str) -> List[Tuple[str, str, str]]:
    """
    Split *text* at h2/h3/h4 boundaries.

    Returns a list of (heading_level, heading_text, section_body) tuples.
    The first (pre-heading) block is treated as a pseudo-section with
    heading level ``""`` and heading text ``""``.
    """
    matches = list(HEADING_RE.finditer(text))
    if not matches:
        return [("", "", text)]

    chunks: List[Tuple[str, str, str]] = []
    # everything before the first heading
    if matches[0].start() > 0:
        chunks.append(("", "", text[: matches[0].start()]))

    for i, m in enumerate(matches):
        level, heading = m.group(1), m.group(2).strip()
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        body = text[start:end].strip("\n")
        chunks.append((level, heading, body))

    return chunks


def chunk_hash(text: str) -> str:
    """Return the hex-encoded SHA-256 digest of *text*."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def estimate_tokens(text: str) -> int:
    """Return a rough token-count estimate for *text*."""
    return int(len(text) * TOKEN_ESTIMATE_FACTOR)


# ---------------------------------------------------------------------------
# File I/O helpers with exception handling
# ---------------------------------------------------------------------------
def read_file_bytes(filepath: Path) -> bytes | None:
    """Read raw bytes, returning ``None`` on expected I/O errors."""
    try:
        return filepath.read_bytes()
    except FileNotFoundError:
        _error(f"File not found: {filepath}")
        return None
    except PermissionError:
        _error(f"Permission denied reading: {filepath}")
        return None
    except IsADirectoryError:
        _error(f"Expected file, got directory: {filepath}")
        return None
    except OSError as exc:
        _error(f"OS error reading {filepath}: {exc}")
        return None


def read_markdown_text(filepath: Path) -> str | None:
    """
    Read a Markdown file as UTF-8 text.

    Falls back to GBK on :class:`UnicodeDecodeError` and returns ``None``
    when the file cannot be decoded at all.
    """
    raw = read_file_bytes(filepath)
    if raw is None:
        return None

    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        _warning(f"UTF-8 decode failed for {filepath}, trying GBK fallback")
        try:
            return raw.decode("gbk")
        except UnicodeDecodeError:
            _error(f"Unable to decode {filepath} as UTF-8 or GBK")
            return None


def write_json_atomic(path: Path, data: Any) -> bool:
    """Write *data* as pretty-printed JSON to *path* (atomically via tmpfile)."""
    tmp = path.with_suffix(".tmp")
    try:
        tmp.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        tmp.replace(path)
        return True
    except PermissionError:
        _error(f"Permission denied writing {path}")
        return False
    except OSError as exc:
        _error(f"OS error writing {path}: {exc}")
        return False


def safe_unlink(path: Path) -> bool:
    """Remove *path*, returning ``True`` on success."""
    try:
        path.unlink()
        return True
    except PermissionError:
        _error(f"Permission denied deleting {path}")
        return False
    except FileNotFoundError:
        return True  # already gone – not an error for our use-case


# ---------------------------------------------------------------------------
# Core sync logic
# ---------------------------------------------------------------------------
def gather_markdown_files(docs_dir: Path) -> List[Path]:
    """Return all ``*.md`` files under *docs_dir*, skipping oversized ones."""
    md_files: List[Path] = []
    if not docs_dir.exists():
        _error(f"Docs directory does not exist: {docs_dir}")
        return md_files

    for filepath in docs_dir.rglob("*.md"):
        try:
            st = filepath.stat()
        except OSError:
            continue
        if st.st_size > MAX_FILE_SIZE:
            _warning(f"Skipping oversized file ({st.st_size} B): {filepath}")
            continue
        md_files.append(filepath)
    return md_files


def build_chunks_for_file(filepath: Path) -> List[Dict[str, Any]] | None:
    """
    Parse a single Markdown file into chunk records.

    Returns ``None`` when the file cannot be read or decoded.
    """
    rel_path = filepath.relative_to(KB_ROOT).as_posix()
    text = read_markdown_text(filepath)
    if text is None:
        return None

    fm_yaml, body = extract_frontmatter(text)
    meta = parse_frontmatter(fm_yaml)

    raw_chunks = split_by_headings(body)
    chunks: List[Dict[str, Any]] = []

    for seq, (level, heading, section_body) in enumerate(raw_chunks, start=1):
        full_text = f"{'#' * len(level)} {heading}\n{section_body}" if level else section_body
        c_hash = chunk_hash(full_text)
        tokens = estimate_tokens(full_text)

        chunk_record: Dict[str, Any] = {
            "id": f"{rel_path}#{seq}",
            "source": rel_path,
            "seq": seq,
            "heading_level": len(level) if level else 0,
            "heading": heading,
            "hash": c_hash,
            "tokens": tokens,
            "text": full_text,
            "meta": meta,
        }
        chunks.append(chunk_record)

    return chunks


def write_chunk_files(
    chunks: List[Dict[str, Any]],
    index_entries: Dict[str, Dict[str, Any]],
) -> None:
    """Persist every chunk as an individual JSON file and update *index_entries*."""
    CHUNKS_DIR.mkdir(parents=True, exist_ok=True)
    for chunk in chunks:
        chunk_id = chunk["id"]
        # sanitise filename – replace path separators and hashes
        safe_name = chunk_id.replace("/", "_").replace("#", "_")
        chunk_path = CHUNKS_DIR / f"{safe_name}.json"

        if not write_json_atomic(chunk_path, chunk):
            continue

        index_entries[chunk_id] = {
            "path": chunk_path.relative_to(KB_ROOT).as_posix(),
            "hash": chunk["hash"],
            "tokens": chunk["tokens"],
            "source": chunk["source"],
            "heading": chunk["heading"],
        }


def load_existing_index() -> Dict[str, Dict[str, Any]]:
    """Load the existing chunk-index.json or return an empty dict."""
    if not CHUNK_INDEX.exists():
        return {}
    try:
        data = json.loads(CHUNK_INDEX.read_text(encoding="utf-8"))
        # Normalise – older versions may have stored a list
        if isinstance(data, dict):
            return data
        return {}
    except (json.JSONDecodeError, OSError) as exc:
        _warning(f"Corrupt or unreadable index ({exc}); starting fresh")
        return {}


def prune_stale_chunks(
    current_ids: set,
    old_index: Dict[str, Dict[str, Any]],
) -> int:
    """Remove chunk files no longer referenced and return number deleted."""
    removed = 0
    for cid, info in list(old_index.items()):
        if cid in current_ids:
            continue
        try:
            chunk_path = CHUNKS_DIR / info["path"]
        except KeyError:
            _warning(f"Index entry for {cid} lacks 'path' field; skipping")
            continue
        if chunk_path.exists() and safe_unlink(chunk_path):
            removed += 1
    return removed


# ---------------------------------------------------------------------------
# Mode implementations
# ---------------------------------------------------------------------------
def mode_full() -> int:
    """Full rebuild – wipe existing chunks and regenerate everything."""
    md_files = gather_markdown_files(DOCS_DIR)
    if not md_files:
        _warning("No Markdown files found")
        return 0

    # Purge old chunks
    if CHUNKS_DIR.exists():
        for old in list(CHUNKS_DIR.glob("*.json")):
            if old.name == "chunk-index.json":
                continue
            safe_unlink(old)

    index_entries: Dict[str, Dict[str, Any]] = {}
    total_chunks = 0

    for filepath in md_files:
        chunks = build_chunks_for_file(filepath)
        if chunks is None:
            continue
        write_chunk_files(chunks, index_entries)
        total_chunks += len(chunks)

    if not write_json_atomic(CHUNK_INDEX, index_entries):
        return 1

    print(f"Full rebuild complete: {total_chunks} chunks from {len(md_files)} files")
    return 0


def mode_incr() -> int:
    """Incremental sync – only update changed chunks and delete stale ones."""
    md_files = gather_markdown_files(DOCS_DIR)
    if not md_files:
        _warning("No Markdown files found")
        return 0

    old_index = load_existing_index()
    new_index: Dict[str, Dict[str, Any]] = {}
    total_written = 0
    total_skipped = 0

    for filepath in md_files:
        chunks = build_chunks_for_file(filepath)
        if chunks is None:
            continue

        for chunk in chunks:
            cid = chunk["id"]
            old_hash = None
            try:
                old_hash = old_index[cid]["hash"]
            except KeyError:
                pass

            if old_hash == chunk["hash"]:
                # unchanged – carry forward existing entry
                try:
                    new_index[cid] = old_index[cid]
                except KeyError:
                    # should not happen, but handle gracefully
                    safe_name = cid.replace("/", "_").replace("#", "_")
                    chunk_path = CHUNKS_DIR / f"{safe_name}.json"
                    new_index[cid] = {
                        "path": chunk_path.relative_to(KB_ROOT).as_posix(),
                        "hash": chunk["hash"],
                        "tokens": chunk["tokens"],
                        "source": chunk["source"],
                        "heading": chunk["heading"],
                    }
                total_skipped += 1
                continue

            # changed or new – write fresh
            safe_name = cid.replace("/", "_").replace("#", "_")
            chunk_path = CHUNKS_DIR / f"{safe_name}.json"
            if write_json_atomic(chunk_path, chunk):
                new_index[cid] = {
                    "path": chunk_path.relative_to(KB_ROOT).as_posix(),
                    "hash": chunk["hash"],
                    "tokens": chunk["tokens"],
                    "source": chunk["source"],
                    "heading": chunk["heading"],
                }
                total_written += 1

    # Remove stale entries
    current_ids = set(new_index.keys())
    removed = prune_stale_chunks(current_ids, old_index)

    if not write_json_atomic(CHUNK_INDEX, new_index):
        return 1

    print(
        f"Incremental sync complete: "
        f"{total_written} written, {total_skipped} unchanged, {removed} removed"
    )
    return 0


def mode_status() -> int:
    """Print summary statistics without writing anything."""
    md_files = gather_markdown_files(DOCS_DIR)
    index = load_existing_index()

    total_src_chunks = 0
    total_src_tokens = 0
    for filepath in md_files:
        chunks = build_chunks_for_file(filepath)
        if chunks is None:
            continue
        total_src_chunks += len(chunks)
        total_src_tokens += sum(c["tokens"] for c in chunks)

    # Count existing chunk files on disk
    existing_chunk_files = list(CHUNKS_DIR.glob("*.json"))
    # Exclude the index itself
    existing_chunk_files = [p for p in existing_chunk_files if p.name != "chunk-index.json"]

    total_disk_bytes = 0
    for p in existing_chunk_files:
        try:
            total_disk_bytes += p.stat().st_size
        except OSError:
            pass

    print(f"Markdown files      : {len(md_files)}")
    print(f"Source chunks       : {total_src_chunks}")
    print(f"Estimated tokens    : {total_src_tokens}")
    print(f"Indexed chunks      : {len(index)}")
    print(f"Chunk files on disk : {len(existing_chunk_files)}")
    print(f"Disk usage          : {total_disk_bytes:,} B " f"({total_disk_bytes / 1024:.1f} KiB)")
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Synchronise knowledge-base Markdown files into chunks",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "modes:\n"
            "  full   – rebuild all chunks from scratch\n"
            "  incr   – incremental update (only changed chunks)\n"
            "  status – show statistics without writing files"
        ),
    )
    parser.add_argument(
        "mode",
        choices=["full", "incr", "status"],
        help="operation mode",
    )
    args = parser.parse_args(argv)

    if args.mode == "full":
        return mode_full()
    if args.mode == "incr":
        return mode_incr()
    if args.mode == "status":
        return mode_status()

    return 2  # unreachable


if __name__ == "__main__":
    sys.exit(main())
