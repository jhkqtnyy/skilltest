# -*- coding: utf-8 -*-
"""Minimal workflow stage timer for xinghan-upgrade-solution-fixed.

Usage:
    from workflow_profiler import WorkflowProfiler

    profiler = WorkflowProfiler('workspace/workflow_timing.json')
    with profiler.stage('industry_research'):
        run_industry_research()
    with profiler.stage('kb_retrieval'):
        run_kb_retrieval()
    with profiler.stage('report_generation'):
        run_report_generation()
    profiler.save()

The JSON file will contain per-stage elapsed seconds and can be used to
identify bottlenecks across report generation runs.
"""
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
from contextlib import contextmanager


class WorkflowProfiler:
    def __init__(self, path: str = "workflow_timing.json"):
        self.path = Path(path)
        self._start_ts = time.time()
        self.records: Dict[str, Any] = {
            "started_at": datetime.fromtimestamp(self._start_ts).strftime("%Y-%m-%d %H:%M:%S"),
            "stages": [],
        }
        self._current: Optional[Dict[str, Any]] = None
        self._overridden: bool = False

    @contextmanager
    def stage(self, name: str):
        start = time.time()
        self._current = {"name": name}
        self._overridden = False
        try:
            yield self._current
        finally:
            if not self._overridden:
                elapsed = time.time() - start
                self._current["elapsed_seconds"] = round(elapsed, 3)
            self.records["stages"].append(self._current)
            self._current = None
            self._overridden = False

    def add_meta(self, **kwargs):
        target = self._current if self._current is not None else self.records
        target.update(kwargs)

    def override_elapsed(self, seconds: float):
        """Override the elapsed time of the current stage."""
        if self._current is not None:
            self._current["elapsed_seconds"] = round(seconds, 3)
            self._overridden = True

    def save(self):
        finished_ts = self._start_ts + sum(s.get("elapsed_seconds", 0) for s in self.records["stages"])
        self.records["finished_at"] = datetime.fromtimestamp(finished_ts).strftime("%Y-%m-%d %H:%M:%S")
        self.path.write_text(json.dumps(self.records, ensure_ascii=False, indent=2), encoding="utf-8")
        return self.records

    def summary(self) -> str:
        lines = [f"Stage                          Time(s)"]
        lines.append("-" * 40)
        total = 0.0
        for s in self.records.get("stages", []):
            elapsed = s.get("elapsed_seconds", 0)
            total += elapsed
            lines.append(f"{s['name']:<30} {elapsed:>8.2f}")
        lines.append("-" * 40)
        lines.append(f"{'Total':<30} {total:>8.2f}")
        return "\n".join(lines)


if __name__ == "__main__":
    import time as _time

    profiler = WorkflowProfiler()
    with profiler.stage("industry_research"):
        _time.sleep(0.1)
        profiler.add_meta(query_count=52, timeouts=[])
    with profiler.stage("kb_retrieval"):
        _time.sleep(0.02)
    with profiler.stage("report_generation"):
        _time.sleep(0.05)
    profiler.save()
    print(profiler.summary())
    print(f"\nSaved to {profiler.path}")
