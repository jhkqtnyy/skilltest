# -*- coding: utf-8 -*-
"""Optimized knowledge-base retrieval for xinghan-upgrade-solution-fixed.

Design goals:
- Never load all chunks by default.
- Layer 1 (index.yaml) / Layer 2 (summary.md) / Layer 3 (sections) should be used
  first; Layer 4 (chunks) is only a fall-back for fuzzy pain-point matching.
- When Layer 4 is needed, pre-filter chunks by query keywords, then score only
  the candidates and return Top-K.
"""

import json
import re
import time
from pathlib import Path
from typing import List, Dict, Any, Optional


DEFAULT_KB_ROOT = Path(r'C:\Users\kingdee\.qoderwork\skills\xinghan-upgrade-solution-fixed\knowledge-base')


def _load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8'))


def extract_keywords(text: str, min_len: int = 2) -> List[str]:
    """Extract search keywords from a query or pain point.

    For Chinese we keep consecutive runs of CJK characters whose length is at
    least min_len. For English/alphanumeric we keep words longer than min_len.
    """
    text = text.lower().strip()
    keywords = []
    # English / alphanumeric words
    for w in re.findall(r'[a-z0-9]+', text):
        if len(w) >= min_len:
            keywords.append(w)
    # Chinese / CJK phrases (2 chars and above)
    for w in re.findall(r'[\u4e00-\u9fff]{' + str(min_len) + r',}', text):
        # also emit shorter substrings of length 2..len to increase recall
        if len(w) <= 6:
            keywords.append(w)
        else:
            # sliding window of length 4 to avoid explosion on long headings
            for i in range(len(w) - 3):
                keywords.append(w[i:i + 4])
    return list(set(keywords))


def _score_chunk(idx_entry: Dict[str, Any], chunk: Dict[str, Any], keywords: List[str],
                 source_weights: Optional[Dict[str, float]] = None) -> float:
    """Fast local scoring for pre-filtered chunks.

    Scoring is intentionally cheap (no embedding model). It is meant to surface
    the most promising chunks for an upstream LLM to re-rank or summarize.
    """
    if source_weights is None:
        source_weights = {
            'starhan/module-docs': 1.2,
            'starhan/solution-docs': 1.1,
            'cangqiu': 1.0,
            'cases.md': 1.0,
            'faq.md': 1.0,
            'ai-suite': 0.5,  # not actively retrieved per skill rule
        }

    heading = (chunk.get('heading') or '').lower()
    text = (chunk.get('text') or '').lower()
    source = (chunk.get('source') or '').lower()

    score = 0.0
    for kw in keywords:
        # heading hit is worth more than body hit
        if kw in heading:
            score += 3.0
        if kw in text:
            score += 1.0
        # source path hit (e.g. query mentions epm and source contains epm)
        if kw in source:
            score += 0.5

    # source-type bonus
    src_lower = source.replace('\\', '/')
    for prefix, weight in source_weights.items():
        if prefix.lower() in src_lower:
            score *= weight
            break

    # small token-length normalization: very short chunks are less informative
    tokens = chunk.get('tokens', 500)
    if tokens < 50:
        score *= 0.7

    return round(score, 3)


def retrieve_chunks(
    queries: List[str],
    kb_root: Path = DEFAULT_KB_ROOT,
    top_k: int = 10,
    max_candidates: int = 50,
    source_weights: Optional[Dict[str, float]] = None,
) -> Dict[str, Any]:
    """Keyword-pre-filtered chunk retrieval.

    Args:
        queries: list of pain points / search queries.
        kb_root: path to knowledge-base folder containing chunks/chunk-index.json.
        top_k: number of chunks to return.
        max_candidates: safety cap on how many chunks to load after keyword filter.
        source_weights: optional per-source-path boosting weights.

    Returns:
        dict with retrieval metadata and top_chunks list.
    """
    start = time.time()
    chunks_dir = kb_root / 'chunks'
    index_path = chunks_dir / 'chunk-index.json'

    if not index_path.exists():
        return {'error': f'chunk-index.json not found at {index_path}', 'top_chunks': []}

    index = _load_json(index_path)

    # Collect keywords from all queries
    all_keywords: List[str] = []
    for q in queries:
        all_keywords.extend(extract_keywords(q))
    all_keywords = list(set(all_keywords))

    if not all_keywords:
        return {'error': 'no usable keywords in queries', 'top_chunks': []}

    # Pre-filter using index only (cheap; no chunk loading yet)
    candidate_keys = []
    for chunk_id, meta in index.items():
        heading = (meta.get('heading') or '').lower()
        source = (meta.get('source') or '').lower()
        text = heading + ' ' + source
        if any(kw in text for kw in all_keywords):
            candidate_keys.append(chunk_id)

    # If keyword filter is too aggressive, broaden by allowing any single keyword
    # in the source path to match
    if len(candidate_keys) < top_k * 2:
        for chunk_id, meta in index.items():
            if chunk_id in candidate_keys:
                continue
            source = (meta.get('source') or '').lower()
            if any(kw in source for kw in all_keywords):
                candidate_keys.append(chunk_id)

    # Hard cap to avoid loading thousands of chunks
    if len(candidate_keys) > max_candidates:
        candidate_keys = candidate_keys[:max_candidates]

    # Load and score candidates
    scored = []
    for chunk_id in candidate_keys:
        meta = index[chunk_id]
        # meta['path'] already starts with 'chunks/'
        chunk_path = kb_root / meta['path']
        if not chunk_path.exists():
            continue
        try:
            chunk = _load_json(chunk_path)
        except Exception:
            continue
        score = _score_chunk(meta, chunk, all_keywords, source_weights)
        scored.append({
            'chunk_id': chunk_id,
            'score': score,
            'source': chunk.get('source'),
            'heading': chunk.get('heading'),
            'heading_level': chunk.get('heading_level'),
            'tokens': chunk.get('tokens'),
            'text_preview': (chunk.get('text') or '')[:300],
            'text': chunk.get('text'),
        })

    scored.sort(key=lambda x: x['score'], reverse=True)
    top = scored[:top_k]
    elapsed = round(time.time() - start, 3)

    return {
        'queries': queries,
        'keywords': all_keywords,
        'total_chunks': len(index),
        'candidates_loaded': len(scored),
        'top_k': top_k,
        'token_estimate': sum(c.get('tokens', 0) for c in top),
        'top_chunks': top,
        'elapsed_seconds': elapsed,
    }


def retrieve_for_report(
    pain_points: List[str],
    modules: Optional[List[str]] = None,
    industry: Optional[str] = None,
    kb_root: Path = DEFAULT_KB_ROOT,
    top_k_per_pain: int = 3,
) -> Dict[str, Any]:
    """Convenience wrapper for report generation.

    Returns a merged Top-K result set across all pain points and modules.
    """
    queries = list(pain_points)
    if modules:
        queries.extend(modules)
    if industry:
        queries.append(industry)

    result = retrieve_chunks(
        queries=queries,
        kb_root=kb_root,
        top_k=max(top_k_per_pain * len(pain_points), 10),
    )

    # Group by source document for downstream citation assembly
    by_source: Dict[str, List[Dict[str, Any]]] = {}
    for ch in result.get('top_chunks', []):
        src = ch.get('source') or 'unknown'
        by_source.setdefault(src, []).append(ch)

    result['by_source'] = by_source
    return result


def main():
    import argparse
    parser = argparse.ArgumentParser(description='Optimized KB chunk retrieval')
    parser.add_argument('--pain', nargs='+', default=[
        '合并报表效率瓶颈，多币种数据失真',
        '供应链计划与执行脱节，跨组织协同排产不足',
        '海外费用报销分散，智能审单能力缺失',
        '版本生命周期与合规风险叠加',
        '系统性能制约业务扩张',
    ], help='pain points to retrieve against')
    parser.add_argument('--modules', nargs='+', default=['财务', '供应链', '费用报销'])
    parser.add_argument('--top-k', type=int, default=5)
    parser.add_argument('--output', default=None)
    args = parser.parse_args()

    result = retrieve_for_report(
        pain_points=args.pain,
        modules=args.modules,
        top_k_per_pain=args.top_k,
    )

    # Print compact summary
    print(f"index total: {result['total_chunks']}, candidates loaded: {result['candidates_loaded']}, "
          f"returned: {len(result['top_chunks'])}, estimated tokens: {result['token_estimate']}")
    for ch in result['top_chunks']:
        print(f"  [{ch['score']:.1f}] {ch['source']} :: {ch['heading']} ({ch['tokens']} tokens)")

    if args.output:
        Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        print(f"saved to {args.output}")


if __name__ == '__main__':
    main()
