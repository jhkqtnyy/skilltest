"""Inject a SmartArt organization chart into a generated docx, replacing the org_chart image."""
import re
import shutil
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from tempfile import TemporaryDirectory
import xml.etree.ElementTree as ET


# Diagram part definitions: (relationship type, source filename, content type)
DIAGRAM_PARTS = [
    ('diagramData', 'data1.xml', 'application/vnd.openxmlformats-officedocument.drawingml.diagramData+xml'),
    ('diagramLayout', 'layout1.xml', 'application/vnd.openxmlformats-officedocument.drawingml.diagramLayout+xml'),
    ('diagramQuickStyle', 'quickStyle1.xml', 'application/vnd.openxmlformats-officedocument.drawingml.diagramStyle+xml'),
    ('diagramColors', 'colors1.xml', 'application/vnd.openxmlformats-officedocument.drawingml.diagramColors+xml'),
    ('diagramDrawing', 'drawing1.xml', 'application/vnd.ms-office.drawingml.diagramDrawing+xml'),
]

REL_NS = 'http://schemas.openxmlformats.org/package/2006/relationships'
CT_NS = 'http://schemas.openxmlformats.org/package/2006/content-types'
R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main'
DGM_NS = 'http://schemas.openxmlformats.org/drawingml/2006/diagram'
W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
WP_NS = 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'


def get_next_rid(rels_root):
    """Find the next available relationship ID in the rels file."""
    max_id = 0
    for rel in rels_root.findall(f'{{{REL_NS}}}Relationship'):
        rid = rel.get('Id', '')
        m = re.match(r'rId(\d+)', rid)
        if m:
            max_id = max(max_id, int(m.group(1)))
    return f'rId{max_id + 1}'


def inject_smartart(docx_path, template_dir, output_path):
    """Replace org_chart image in docx_path with SmartArt from template_dir."""
    docx_path = Path(docx_path)
    template_dir = Path(template_dir)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        # Extract the target docx
        with ZipFile(docx_path, 'r') as zf:
            zf.extractall(tmp_path)

        # Read document.xml.rels
        rels_path = tmp_path / 'word' / '_rels' / 'document.xml.rels'
        rels_tree = ET.parse(rels_path)
        rels_root = rels_tree.getroot()

        # Find and remove image relationship(s) targeting media/image*.png
        image_rid = None
        for rel in list(rels_root.findall(f'{{{REL_NS}}}Relationship')):
            target = rel.get('Target', '')
            rel_type = rel.get('Type', '')
            if 'image' in rel_type and target.startswith('media/') and target.endswith('.png'):
                image_rid = rel.get('Id')
                rels_root.remove(rel)
                # Delete the image file
                img_path = tmp_path / 'word' / target.replace('/', '\\')
                if img_path.exists():
                    img_path.unlink()
                print(f'Removed image relationship {image_rid}: {target}')

        # Assign sequential new rIds for diagram parts
        rel_type_map = {
            'diagramData': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/diagramData',
            'diagramLayout': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/diagramLayout',
            'diagramQuickStyle': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/diagramQuickStyle',
            'diagramColors': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/diagramColors',
            'diagramDrawing': 'http://schemas.microsoft.com/office/2007/relationships/diagramDrawing',
        }
        max_id = 0
        for rel in rels_root.findall(f'{{{REL_NS}}}Relationship'):
            rid = rel.get('Id', '')
            m = re.match(r'rId(\d+)', rid)
            if m:
                max_id = max(max_id, int(m.group(1)))

        new_rids = {}
        for idx, (key, filename, _) in enumerate(DIAGRAM_PARTS, start=1):
            new_rids[key] = f'rId{max_id + idx}'
            rel = ET.SubElement(rels_root, f'{{{REL_NS}}}Relationship')
            rel.set('Id', new_rids[key])
            rel.set('Type', rel_type_map[key])
            rel.set('Target', f'diagrams/{filename}')

        # Write back rels
        rels_tree.write(rels_path, encoding='utf-8', xml_declaration=True)

        # Copy diagram XML files from template
        diagrams_dir = tmp_path / 'word' / 'diagrams'
        diagrams_dir.mkdir(exist_ok=True)
        for key, filename, _ in DIAGRAM_PARTS:
            src = template_dir / 'word' / 'diagrams' / filename
            dst = diagrams_dir / filename
            shutil.copy(src, dst)

        # Update [Content_Types].xml
        ct_path = tmp_path / '[Content_Types].xml'
        ct_tree = ET.parse(ct_path)
        ct_root = ct_tree.getroot()
        existing_parts = {ov.get('PartName') for ov in ct_root.findall(f'{{{CT_NS}}}Override')}
        for key, filename, content_type in DIAGRAM_PARTS:
            part_name = f'/word/diagrams/{filename}'
            if part_name not in existing_parts:
                ov = ET.SubElement(ct_root, f'{{{CT_NS}}}Override')
                ov.set('PartName', part_name)
                ov.set('ContentType', content_type)
        ct_tree.write(ct_path, encoding='utf-8', xml_declaration=True)

        # Update data1.xml drawing relationship reference to use new diagramDrawing rId
        data_path = diagrams_dir / 'data1.xml'
        data_text = data_path.read_text(encoding='utf-8')
        # Replace the old drawing relId (usually rId8) with the new one
        # The template has relId="rId8"; we'll replace any relId attribute pointing to a drawing
        data_text = re.sub(
            r'relId=\"rId\d+\"',
            f'relId="{new_rids["diagramDrawing"]}"',
            data_text
        )
        data_path.write_text(data_text, encoding='utf-8')

        # Read document.xml and replace the image drawing with SmartArt drawing
        doc_xml_path = tmp_path / 'word' / 'document.xml'
        doc_text = doc_xml_path.read_text(encoding='utf-8')

        # Build the SmartArt drawing markup with new rIds (inline so it flows with text)
        smartart_drawing = f'''<w:drawing xmlns:w="{W_NS}" xmlns:wp="{WP_NS}" xmlns:a="{A_NS}" xmlns:dgm="{DGM_NS}" xmlns:r="{R_NS}">
          <wp:inline distT="0" distB="0" distL="0" distR="0">
            <wp:extent cx="5039370" cy="3962400"/>
            <wp:effectExtent l="0" t="0" r="0" b="0"/>
            <wp:docPr id="1042744621" name="项目组织架构图"/>
            <wp:cNvGraphicFramePr/>
            <a:graphic>
              <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/diagram">
                <dgm:relIds r:dm="{new_rids['diagramData']}" r:lo="{new_rids['diagramLayout']}" r:qs="{new_rids['diagramQuickStyle']}" r:cs="{new_rids['diagramColors']}"/>
              </a:graphicData>
            </a:graphic>
          </wp:inline>
        </w:drawing>'''

        # Replace the image drawing block (the one referencing image_rid) with SmartArt
        if image_rid:
            pattern = rf'(<w:drawing[^>]*>.*?<a:blip[^>]*r:embed="{image_rid}"[^/]*/>.*?</w:drawing>)'
            new_doc_text, count = re.subn(pattern, smartart_drawing, doc_text, flags=re.S)
            if count == 0:
                # Fallback: remove any w:drawing containing a blip
                pattern2 = r'<w:drawing[^>]*>.*?</w:drawing>'
                new_doc_text, count2 = re.subn(pattern2, smartart_drawing, doc_text, flags=re.S)
                print(f'Fallback replaced {count2} drawing block(s)')
            else:
                print(f'Replaced image drawing block with SmartArt ({count})')
            doc_text = new_doc_text
        else:
            # If no image found, append SmartArt at end (shouldn't happen)
            print('Warning: no image relationship found; appending SmartArt at end')
            doc_text = doc_text.replace('</w:body>', smartart_drawing + '</w:body>')

        doc_xml_path.write_text(doc_text, encoding='utf-8')

        # Repack the docx
        with ZipFile(output_path, 'w', ZIP_DEFLATED) as zf_out:
            for file_path in tmp_path.rglob('*'):
                if file_path.is_file():
                    arcname = file_path.relative_to(tmp_path).as_posix()
                    zf_out.write(file_path, arcname)

    print(f'Saved: {output_path}')


if __name__ == '__main__':
    base = Path(r'C:\Users\kingdee\.qoderwork\workspace\mr8khx892847j9gl\outputs')
    template = Path(r'C:\Users\kingdee\.qoderwork\workspace\mr8khx892847j9gl\unpacked_template')
    for name in ['solution_report.docx', 'proposal_report.docx']:
        inject_smartart(base / name, template, base / name)
