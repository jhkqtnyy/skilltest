# -*- coding: utf-8 -*-
r"""End-to-end workflow runner for xinghan-upgrade-solution-fixed.

Usage:
    python run_workflow.py --workspace C:\path\to\workspace

The runner executes the standard 5-step pipeline and records per-stage
elapsed time to workspace/workflow_timing.json. Intermediate JSON files
(customer_profile.json, industry_research.json, kb_retrieval.json) are read
from the workspace; if they are missing, the corresponding stage is skipped
and reported as failed.
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

# Allow importing workflow_profiler from the same directory or skill scripts dir
sys.path.insert(0, str(Path(__file__).resolve().parent))
from workflow_profiler import WorkflowProfiler


def run():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--workspace",
        type=Path,
        default=Path.cwd(),
        help="Workspace directory containing customer_profile.json etc.",
    )
    parser.add_argument(
        "--skip-industry-research",
        action="store_true",
        help="Skip industry research timing (use cached industry_research.json).",
    )
    parser.add_argument(
        "--skip-kb-retrieval",
        action="store_true",
        help="Skip KB retrieval timing (use cached kb_retrieval.json).",
    )
    args = parser.parse_args()

    workspace = args.workspace.resolve()
    if not workspace.exists():
        raise SystemExit(f"Workspace does not exist: {workspace}")

    outputs_dir = workspace / "outputs"
    outputs_dir.mkdir(exist_ok=True)

    profiler = WorkflowProfiler(workspace / "workflow_timing.json")

    # Stage 1: input validation / load customer profile
    with profiler.stage("input_validation"):
        profile_path = workspace / "customer_profile.json"
        if not profile_path.exists():
            raise SystemExit(f"Missing customer profile: {profile_path}")
        profile = json.loads(profile_path.read_text(encoding="utf-8"))
        profiler.add_meta(customer_name=profile.get("客户名称"), industry=profile.get("所属行业"))

    # Stage 2: industry research
    def run_industry_research_stage(use_cache):
        ir_path = workspace / "industry_research.json"
        if ir_path.exists():
            ir = json.loads(ir_path.read_text(encoding="utf-8"))
            actual_elapsed = ir.get("elapsed_seconds", ir.get("total_elapsed_seconds", 0))
            profiler.add_meta(
                source="cached" if use_cache else "executed",
                query_count=ir.get("query_count", 0),
                mode=ir.get("mode", "regular"),
                dimensions_used=ir.get("dimensions_used", []),
            )
            profiler.override_elapsed(actual_elapsed)
        else:
            profiler.add_meta(source="missing", query_count=0, mode="regular", dimensions_used=[])

    with profiler.stage("industry_research"):
        run_industry_research_stage(use_cache=True)

    # Stage 3: KB retrieval
    def run_kb_retrieval_stage(use_cache):
        kb_path = workspace / "kb_retrieval.json"
        if kb_path.exists():
            kb = json.loads(kb_path.read_text(encoding="utf-8"))
            if isinstance(kb, dict):
                candidates_loaded = kb.get("candidates_loaded", 0)
                actual_elapsed = kb.get("elapsed_seconds", 0)
            else:
                candidates_loaded = len(kb)
                actual_elapsed = 0
            profiler.add_meta(source="cached" if use_cache else "executed", candidates_loaded=candidates_loaded)
            profiler.override_elapsed(actual_elapsed)
        else:
            profiler.add_meta(source="missing", candidates_loaded=0)

    with profiler.stage("kb_retrieval"):
        run_kb_retrieval_stage(use_cache=True)

    # Stage 4: Markdown report generation
    with profiler.stage("report_generation"):
        generate_script = workspace / "generate_reports.py"
        if not generate_script.exists():
            raise SystemExit(f"Missing report generator: {generate_script}")
        result = subprocess.run(
            [sys.executable, str(generate_script)],
            cwd=str(workspace),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if result.returncode != 0:
            raise SystemExit(f"report_generation failed:\n{result.stderr}")
        profiler.add_meta(
            outputs=[
                "outputs/solution_report.md",
                "outputs/proposal_report.md",
            ]
        )

    # Stage 5: docx conversion and SmartArt injection
    with profiler.stage("docx_conversion"):
        md2docx_script = workspace / "md2docx.py"
        if not md2docx_script.exists():
            raise SystemExit(f"Missing docx converter: {md2docx_script}")
        result = subprocess.run(
            [sys.executable, str(md2docx_script)],
            cwd=str(workspace),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if result.returncode != 0:
            raise SystemExit(f"docx_conversion failed:\n{result.stderr}")
        profiler.add_meta(
            outputs=[
                "outputs/金蝶星瀚系统升级解决方案报告.docx",
                "outputs/金蝶星瀚系统升级立项报告.docx",
            ]
        )

    records = profiler.save()
    print(profiler.summary())
    print(f"\nTiming saved to: {profiler.path}")
    return records


if __name__ == "__main__":
    run()
