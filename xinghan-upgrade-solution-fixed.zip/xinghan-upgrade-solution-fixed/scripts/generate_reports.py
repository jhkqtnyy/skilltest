# -*- coding: utf-8 -*-
"""Generate Kingdee Xinghan upgrade reports from JSON content.

Inputs (in workspace):
    customer_profile.json   - customer questionnaire / profile
    report_content.json     - report text, tables, references
    industry_research.json  - (optional) used only if content JSON references it
    kb_retrieval.json       - (optional) used only if content JSON references it

Outputs:
    outputs/solution_report.md
    outputs/proposal_report.md
"""
import json
import re
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent
OUT = BASE / 'outputs'
OUT.mkdir(exist_ok=True)

# ---------------------------------------------------------------------------
# Load inputs
# ---------------------------------------------------------------------------
profile = json.loads((BASE / 'customer_profile.json').read_text(encoding='utf-8'))
content = json.loads((BASE / 'report_content.json').read_text(encoding='utf-8'))

REFS = content['refs']
today = datetime.now().strftime('%Y年%m月%d日')


def profile_value(key: str) -> str:
    return str(profile.get(key, ''))


# ---------------------------------------------------------------------------
# Citation handling
# ---------------------------------------------------------------------------
class CitationRegistry:
    def __init__(self, refs):
        self.refs = refs
        self.order = []
        self._last_ended_with_cite = False

    def cite(self, key):
        if key not in self.refs:
            # Unknown key: leave marker so it is visible during debugging.
            return f'[{key}]'
        if key not in self.order:
            self.order.append(key)
        idx = self.order.index(key) + 1
        supers = ['⁰', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹']
        result = ''.join(supers[int(d)] for d in str(idx))
        if self._last_ended_with_cite:
            result = '\u200c' + result
        self._last_ended_with_cite = True
        return result

    def reset_adjacency(self):
        self._last_ended_with_cite = False

    def get_ref_list(self):
        lines = []
        for i, key in enumerate(self.order, 1):
            r = self.refs[key]
            url = r.get('url', '')
            if url:
                lines.append(f"[{i}] {r['title']} {url}")
            else:
                lines.append(f"[{i}] {r['title']}")
        return lines


class CitationLines:
    """List-like container that resets citation adjacency after each append."""
    def __init__(self, registry):
        self.registry = registry
        self._lines = []

    def append(self, text):
        self._lines.append(text)
        self.registry.reset_adjacency()

    def __iter__(self):
        return iter(self._lines)

    def get_lines(self):
        return self._lines


_PLACEHOLDERS = {
    '客户名称': lambda: profile_value('客户名称'),
    '客户简称': lambda: profile_value('客户简称'),
    'today': lambda: today,
}

_CITE_RE = re.compile(r'\{\{([a-z_0-9]+)\}\}')
_PLACEHOLDER_RE = re.compile(r'\{([\u4e00-\u9fa5_a-zA-Z0-9]+)\}')


def render_text(text: str, registry: CitationRegistry) -> str:
    """Replace {客户名称}/{today} and {{cite_key}} markers."""
    if not text:
        return ''

    def repl_placeholder(m):
        key = m.group(1)
        return _PLACEHOLDERS.get(key, lambda: m.group(0))()

    text = _PLACEHOLDER_RE.sub(repl_placeholder, text)

    tokens = _CITE_RE.split(text)
    result_parts = []
    for i, tok in enumerate(tokens):
        if i % 2 == 0:
            if tok:
                result_parts.append(tok)
                registry.reset_adjacency()
        else:
            result_parts.append(registry.cite(tok))
    return ''.join(result_parts)


def append_paragraph(lines: CitationLines, text: str, registry: CitationRegistry):
    lines.append(render_text(text, registry))


def append_bullet(lines: CitationLines, text: str, registry: CitationRegistry):
    lines.append(render_text(text, registry))


def append_numbered(lines: CitationLines, num: int, text: str, registry: CitationRegistry):
    lines.append(f"{num}. {render_text(text, registry)}")


def build_markdown_table(headers, rows, registry: CitationRegistry):
    lines = []
    lines.append('| ' + ' | '.join(headers) + ' |')
    lines.append('|' + '|'.join(['---' for _ in headers]) + '|')
    for row in rows:
        escaped = [render_text(str(cell), registry).replace('|', '\\|') for cell in row]
        lines.append('| ' + ' | '.join(escaped) + ' |')
    return '\n'.join(lines)


def add_table(lines: CitationLines, headers, rows):
    lines.append(build_markdown_table(headers, rows, lines.registry))


# ---------------------------------------------------------------------------
# Solution report
# ---------------------------------------------------------------------------
def generate_solution():
    c = CitationRegistry(REFS)
    lines = CitationLines(c)
    sol = content['solution']
    ch4 = content['chapter4']
    q = content['quotation_table']

    # Title page (two-line centered title)
    lines.append(f"# {profile['客户名称']}")
    lines.append(f"#!SUBTITLE {sol['report_title_suffix']}")
    lines.append('')
    lines.append('**编制单位**：金蝶软件（中国）有限公司')
    lines.append('')
    lines.append(f'**编制日期**：{today}')
    lines.append('')
    lines.append(r'\newpage')
    lines.append('')

    # 一、趋势洞察与现状分析
    lines.append('# 一、趋势洞察与现状分析')
    lines.append('')

    lines.append('## 1.1 趋势洞察')
    lines.append('')
    append_paragraph(lines, sol['trend_insight'], c)
    lines.append('')

    lines.append('## 1.2 现状分析')
    lines.append('')
    lines.append('### 1.2.1 项目背景')
    lines.append('')
    append_paragraph(lines, sol['project_background'], c)
    lines.append('')

    lines.append('### 1.2.2 系统现状')
    lines.append('')
    append_paragraph(lines, sol['system_status'], c)
    lines.append('')

    lines.append('### 1.2.3 当前痛点')
    lines.append('')
    for item in sol['pain_points']:
        lines.append(f"**{item['title']}**")
        lines.append('')
        append_paragraph(lines, item['desc'], c)
        lines.append('')

    lines.append('## 1.3 风险点总结')
    lines.append('')
    add_table(lines, sol['risks']['headers'], sol['risks']['rows'])
    lines.append('')

    # 二、星瀚系统升级解决方案
    lines.append('# 二、星瀚系统升级解决方案')
    lines.append('')
    for item in sol['solutions']:
        lines.append(f"## {item['title']}")
        lines.append('')
        append_paragraph(lines, f"{item['text']} {item['source_comment']}", c)

    lines.append('## 2.6 相关行业成功案例')
    lines.append('')
    add_table(lines, sol['cases']['headers'], sol['cases']['rows'])
    lines.append('')

    # 三、预期价值
    lines.append('# 三、预期价值')
    lines.append('')
    append_paragraph(lines, sol['expected_value_intro'], c)
    lines.append('')
    for para in sol['expected_values']:
        append_bullet(lines, para, c)
        lines.append('')

    # 四、升级规划及保障
    lines.append('# 四、升级规划及保障')
    lines.append('')
    append_paragraph(lines, sol['chapter4_summary'], c)
    lines.append('')

    lines.append('## 4.1 项目范围')
    lines.append('')
    lines.append('### 组织范围')
    lines.append('')
    add_table(lines, ch4['org_scope']['headers'], ch4['org_scope']['rows'])
    lines.append('')
    lines.append('### 业务/系统范围')
    lines.append('')
    add_table(lines, ch4['business_scope']['headers'], ch4['business_scope']['rows'])
    lines.append('')
    lines.append('### 二次开发范围')
    lines.append('')
    add_table(lines, ch4['custom_scope']['headers'], ch4['custom_scope']['rows'])
    lines.append('')

    lines.append('## 4.2 升级整体计划')
    lines.append('')
    lines.append('### 阶段计划')
    lines.append('')
    add_table(lines, ch4['phase_plan']['headers'], ch4['phase_plan']['rows'])
    lines.append('')
    lines.append('### WBS计划')
    lines.append('')
    add_table(lines, ch4['wbs']['headers'], ch4['wbs']['rows'])
    lines.append('')

    lines.append('## 4.3 风险评估及应对措施')
    lines.append('')
    add_table(lines, ch4['risks']['headers'], ch4['risks']['rows'])
    lines.append('')

    lines.append('## 4.4 升级资源保障')
    lines.append('')
    lines.append('本项目由甲乙双方共同协商、共同推进。双方应本着精诚合作、权责对等的原则，履行各自职责，保障项目顺利开展及验收。')
    lines.append('')
    lines.append('**沟通机制**')
    lines.append('')
    append_paragraph(lines, ch4['communication_mechanism'], c)
    lines.append('')
    lines.append('**项目组织架构**')
    lines.append('')
    lines.append('![项目组织架构图](org_chart.png)')
    lines.append('')

    # 五、商务报价
    lines.append('# 五、商务报价')
    lines.append('')
    add_table(lines, q['headers'], q['rows'])
    lines.append('')

    # 六、下一步行动
    lines.append('# 六、下一步行动')
    lines.append('')
    for i, act in enumerate(sol['next_actions'], 1):
        append_numbered(lines, i, act, c)
        lines.append('')

    # References
    lines.append(r'\newpage')
    lines.append('')
    lines.append('# 参考资料')
    lines.append('')
    for ref in c.get_ref_list():
        lines.append(ref)
    lines.append('')

    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Proposal report
# ---------------------------------------------------------------------------
def generate_proposal():
    c = CitationRegistry(REFS)
    lines = CitationLines(c)
    prop = content['proposal']
    ch4 = content['chapter4']

    # Title page (two-line centered title)
    lines.append(f"# {profile['客户名称']}")
    lines.append(f"#!SUBTITLE {prop['report_title_suffix']}")
    lines.append('')
    lines.append('**编制单位**：金蝶软件（中国）有限公司')
    lines.append('')
    lines.append(f'**编制日期**：{today}')
    lines.append('')
    lines.append(r'\newpage')
    lines.append('')

    # 一、项目背景
    lines.append('# 一、项目背景')
    lines.append('')

    lines.append('## 1.1 趋势洞察分析')
    lines.append('')
    for para in prop['trend_insight_paragraphs']:
        append_paragraph(lines, para, c)
        lines.append('')

    lines.append('## 1.2 系统概况与升级必要性')
    lines.append('')
    lines.append('### 1.2.1 系统概况')
    lines.append('')
    append_paragraph(lines, prop['system_overview'], c)
    lines.append('')

    lines.append('### 1.2.2 升级必要性')
    lines.append('')
    for item in prop['upgrade_necessity']:
        lines.append(f"**{item['theme']}**：{render_text(item['content'], c)}")
        lines.append('')

    # 二、升级目标与预期效果
    lines.append('# 二、升级目标与预期效果')
    lines.append('')
    append_paragraph(lines, prop['goal_overview'], c)
    lines.append('')
    for goal in prop['goals']:
        append_bullet(lines, goal, c)
        lines.append('')

    # 三、星瀚系统升级解决方案
    lines.append('# 三、星瀚系统升级解决方案')
    lines.append('')
    lines.append('## 3.1 升级解决方案')
    lines.append('')
    append_paragraph(lines, prop['solution_intro'], c)
    lines.append('')
    for point in prop['solution_points']:
        append_paragraph(lines, point, c)
        lines.append('')

    lines.append('## 3.2 升级技术路线')
    lines.append('')
    append_paragraph(lines, '本次升级采用标准产品业务功能关键流程测试，定制开发内容利用升级兼容性扫描工具进行提前扫描，进行兼容性调整优化等，测试没有问题及解决方案明确后进行正式升级切换，最大限度减少业务中断。', c)
    lines.append('')
    for item in prop['tech_route_items']:
        append_bullet(lines, item, c)
        lines.append('')

    # 四、升级规划及保障
    lines.append('# 四、升级规划及保障')
    lines.append('')
    append_paragraph(lines, content['solution']['chapter4_summary'], c)
    lines.append('')

    lines.append('## 4.1 项目范围')
    lines.append('')
    lines.append('### 组织范围')
    lines.append('')
    add_table(lines, ch4['org_scope']['headers'], ch4['org_scope']['rows'])
    lines.append('')
    lines.append('### 业务/系统范围')
    lines.append('')
    add_table(lines, ch4['business_scope']['headers'], ch4['business_scope']['rows'])
    lines.append('')
    lines.append('### 二次开发范围')
    lines.append('')
    add_table(lines, ch4['custom_scope']['headers'], ch4['custom_scope']['rows'])
    lines.append('')

    lines.append('## 4.2 升级整体计划')
    lines.append('')
    lines.append('### 阶段计划')
    lines.append('')
    add_table(lines, ch4['phase_plan']['headers'], ch4['phase_plan']['rows'])
    lines.append('')
    lines.append('### WBS计划')
    lines.append('')
    add_table(lines, ch4['wbs']['headers'], ch4['wbs']['rows'])
    lines.append('')

    lines.append('## 4.3 风险评估及应对措施')
    lines.append('')
    add_table(lines, ch4['risks']['headers'], ch4['risks']['rows'])
    lines.append('')

    lines.append('## 4.4 升级资源保障')
    lines.append('')
    lines.append('本项目由甲乙双方共同协商、共同推进。双方应本着精诚合作、权责对等的原则，履行各自职责，保障项目顺利开展及验收。')
    lines.append('')
    lines.append('**甲方职责保障**')
    lines.append('')
    for i, item in enumerate(ch4['party_a_responsibilities'], 1):
        append_numbered(lines, i, item, c)
        lines.append('')
    lines.append('**乙方职责保障**')
    lines.append('')
    for i, item in enumerate(ch4['party_b_responsibilities'], 1):
        append_numbered(lines, i, item, c)
        lines.append('')
    lines.append('**沟通机制**')
    lines.append('')
    append_paragraph(lines, ch4['communication_mechanism'], c)
    lines.append('')
    lines.append('**项目组织架构**')
    lines.append('')
    lines.append('![项目组织架构图](org_chart.png)')
    lines.append('')

    # 五、效益分析
    lines.append('# 五、效益分析')
    lines.append('')
    lines.append('## 5.1 成本投入')
    lines.append('')
    add_table(lines, prop['cost_table']['headers'], prop['cost_table']['rows'])
    lines.append('')
    lines.append('## 5.2 效益分析')
    lines.append('')
    for item in prop['benefit_items']:
        append_bullet(lines, item, c)
        lines.append('')

    # 六、下一步工作
    lines.append('# 六、下一步工作')
    lines.append('')
    for item in prop['next_steps']:
        append_paragraph(lines, item, c)
        lines.append('')

    # References
    lines.append(r'\newpage')
    lines.append('')
    lines.append('# 参考资料')
    lines.append('')
    for ref in c.get_ref_list():
        lines.append(ref)
    lines.append('')

    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    solution_md = generate_solution()
    proposal_md = generate_proposal()

    (OUT / 'solution_report.md').write_text(solution_md, encoding='utf-8')
    (OUT / 'proposal_report.md').write_text(proposal_md, encoding='utf-8')

    print('Generated:')
    print(OUT / 'solution_report.md')
    print(OUT / 'proposal_report.md')
