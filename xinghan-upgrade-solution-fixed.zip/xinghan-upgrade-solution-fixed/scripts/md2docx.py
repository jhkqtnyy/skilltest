"""
Markdown to docx converter for xinghan-upgrade-solution-fixed reports.
Follows references/output-spec.md font/page-break/table requirements.
"""
import re
from pathlib import Path
from docx import Document
from docx.shared import Pt, Cm, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from org_chart import generate_org_chart
import inject_smartart
import create_smartart_template


def set_run_font(run, font_name='宋体', font_size=Pt(10.5), bold=False, color=RGBColor(0, 0, 0), italic=False):
    """Set run font with explicit East Asian / ascii / hAnsi fonts."""
    run.font.size = font_size
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    run.font.name = 'Times New Roman'
    rPr = run._element.find(qn('w:rPr'))
    if rPr is None:
        rPr = OxmlElement('w:rPr')
        run._element.insert(0, rPr)
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rPr.insert(0, rFonts)
    rFonts.set(qn('w:eastAsia'), font_name)
    rFonts.set(qn('w:ascii'), 'Times New Roman')
    rFonts.set(qn('w:hAnsi'), 'Times New Roman')


SUPER_DIGITS = '⁰¹²³⁴⁵⁶⁷⁸⁹'
ZWNJ = '\u200c'


def add_rich_text(paragraph, text, font_name='宋体', font_size=Pt(10.5), color=RGBColor(0, 0, 0), bold=False):
    """Add text to paragraph, handling **bold** markers and superscript citations."""
    # Strip HTML comments
    text = re.sub(r'<!--.*?-->', '', text).strip()
    if not text:
        return
    # Split by bold markers first
    parts = re.split(r'(\*\*.*?\*\*)', text)
    for part in parts:
        if part.startswith('**') and part.endswith('**'):
            add_rich_text(paragraph, part[2:-2], font_name, font_size, color, bold=True)
            continue
        # Within each non-bold segment, split by superscript citations
        # Citation sequences may be separated by ZWNJ to distinguish adjacency.
        tokens = re.split(r'((?:[' + SUPER_DIGITS + r']' + ZWNJ + r'?)+)', part)
        for token in tokens:
            if not token:
                continue
            if re.match(r'^[' + SUPER_DIGITS + ZWNJ + r']+$', token):
                # Citation token: split on ZWNJ for adjacent citations
                for seq in token.split(ZWNJ):
                    if not seq:
                        continue
                    run = paragraph.add_run(seq)
                    set_run_font(run, font_name, font_size, bold=bold, color=color)
                    # Apply superscript formatting
                    rPr = run._element.find(qn('w:rPr'))
                    if rPr is None:
                        rPr = OxmlElement('w:rPr')
                        run._element.insert(0, rPr)
                    vertAlign = OxmlElement('w:vertAlign')
                    vertAlign.set(qn('w:val'), 'superscript')
                    rPr.append(vertAlign)
            else:
                run = paragraph.add_run(token)
                set_run_font(run, font_name, font_size, bold=bold, color=color)


def add_heading(doc, text, level, customer_name=None):
    """Add heading with proper font and alignment."""
    font_cfg = {
        1: ('微软雅黑', Pt(18)),
        2: ('微软雅黑', Pt(16)),
        3: ('微软雅黑', Pt(14)),
        4: ('微软雅黑', Pt(12)),
    }
    font_name, font_size = font_cfg.get(level, ('微软雅黑', Pt(12)))
    para = doc.add_heading(text, level=level)
    para.alignment = WD_ALIGN_PARAGRAPH.LEFT
    for run in para.runs:
        set_run_font(run, font_name, font_size, bold=True)
        if level == 4:
            run.font.italic = False
    return para


def add_page_break(doc):
    """Insert a page break."""
    para = doc.add_paragraph()
    run = para.add_run()
    br = OxmlElement('w:br')
    br.set(qn('w:type'), 'page')
    run._element.append(br)


def add_table(doc, headers, rows):
    """Add table with header styling."""
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = 'Table Grid'
    # Header
    for i, header in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = ''
        p = cell.paragraphs[0]
        run = p.add_run(header)
        set_run_font(run, '微软雅黑', Pt(10.5), bold=True, color=RGBColor(255, 255, 255))
        tcPr = cell._element.find(qn('w:tcPr'))
        if tcPr is None:
            tcPr = OxmlElement('w:tcPr')
            cell._element.insert(0, tcPr)
        shading = OxmlElement('w:shd')
        shading.set(qn('w:fill'), '2F5496')
        shading.set(qn('w:val'), 'clear')
        tcPr.append(shading)
    # Data rows
    for r_idx, row_data in enumerate(rows):
        for c_idx, cell_text in enumerate(row_data):
            cell = table.rows[r_idx + 1].cells[c_idx]
            cell.text = ''
            p = cell.paragraphs[0]
            add_rich_text(p, str(cell_text), '宋体', Pt(10.5))
            # Alternate row shading
            if r_idx % 2 == 1:
                tcPr = cell._element.find(qn('w:tcPr'))
                if tcPr is None:
                    tcPr = OxmlElement('w:tcPr')
                    cell._element.insert(0, tcPr)
                shading = OxmlElement('w:shd')
                shading.set(qn('w:fill'), 'F2F2F2')
                shading.set(qn('w:val'), 'clear')
                tcPr.append(shading)
    return table


def parse_markdown(md_text):
    """Parse markdown into blocks."""
    lines = md_text.splitlines()
    blocks = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        stripped = line.strip()
        # Skip empty lines
        if not stripped:
            i += 1
            continue
        # Page break
        if stripped == r'\newpage':
            blocks.append({'type': 'page_break'})
            i += 1
            continue
        # Images
        m = re.match(r'!\[(.*?)\]\((.*?)\)', stripped)
        if m:
            blocks.append({'type': 'image', 'alt': m.group(1), 'src': m.group(2)})
            i += 1
            continue
        # Subtitle directive for title page (e.g. #!SUBTITLE 升级解决方案)
        if stripped.startswith('#!SUBTITLE '):
            blocks.append({'type': 'subtitle', 'text': stripped[11:].strip()})
            i += 1
            continue
        # Headings
        if stripped.startswith('# '):
            blocks.append({'type': 'heading1', 'text': stripped[2:].strip()})
            i += 1
            continue
        if stripped.startswith('## '):
            blocks.append({'type': 'heading2', 'text': stripped[3:].strip()})
            i += 1
            continue
        if stripped.startswith('### '):
            blocks.append({'type': 'heading3', 'text': stripped[4:].strip()})
            i += 1
            continue
        if stripped.startswith('#### '):
            blocks.append({'type': 'heading4', 'text': stripped[5:].strip()})
            i += 1
            continue
        # Tables
        if stripped.startswith('|'):
            table_lines = []
            while i < n and lines[i].strip().startswith('|'):
                table_lines.append(lines[i].strip())
                i += 1
            # Filter separator line
            data_lines = [l for l in table_lines if not re.match(r'^\|[-\s|:]+\|$', l)]
            if data_lines:
                rows_raw = [parse_table_row(l) for l in data_lines]
                headers = rows_raw[0]
                rows = rows_raw[1:]
                blocks.append({'type': 'table', 'headers': headers, 'rows': rows})
            continue
        # Numbered list item
        m = re.match(r'^(\d+)\.\s+(.*)$', stripped)
        if m:
            blocks.append({'type': 'numbered_item', 'text': m.group(2), 'num': int(m.group(1))})
            i += 1
            continue
        # Bullet list item (• or -)
        if stripped.startswith('• ') or stripped.startswith('- '):
            text = stripped[2:].strip()
            blocks.append({'type': 'bullet_item', 'text': text})
            i += 1
            continue
        # Paragraph
        blocks.append({'type': 'paragraph', 'text': stripped})
        i += 1
    return blocks


def parse_table_row(line):
    """Parse a markdown table row into cells."""
    # Remove leading/trailing |
    line = line.strip()
    if line.startswith('|'):
        line = line[1:]
    if line.endswith('|'):
        line = line[:-1]
    cells = [cell.strip() for cell in line.split('|')]
    return cells


def generate_docx(md_path, output_path, customer_name):
    md_text = Path(md_path).read_text(encoding='utf-8')
    blocks = parse_markdown(md_text)

    doc = Document()
    section = doc.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(3.17)
    section.right_margin = Cm(3.17)

    # Track title page state and references state
    in_title_page = False
    title_page_done = False
    in_references = False

    i = 0
    n = len(blocks)
    while i < n:
        block = blocks[i]
        btype = block['type']

        # Title page detection
        if btype == 'heading1' and not title_page_done:
            in_title_page = True
            # Title page layout rule:
            # - Customer name at ~1/3 of page content area (8cm from top margin).
            # - Report type directly below customer name.
            # - 编制单位/编制日期 slightly below 2/3 (~17cm from top margin),
            #   i.e. 9cm below the report type, to avoid touching page bottom.
            # A4 content height = 29.7 - 2.54(top) - 2.54(bottom) = 24.62cm.
            para = doc.add_paragraph()
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            para.paragraph_format.space_before = Cm(8.0)
            run = para.add_run(block['text'])
            set_run_font(run, '微软雅黑', Pt(22), bold=True)

            # Optional subtitle directive (report type) directly below customer name.
            j = i + 1
            if j < n and blocks[j]['type'] == 'subtitle':
                p_sub = doc.add_paragraph()
                p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
                # No extra space before subtitle; keep it directly under the customer name.
                run_sub = p_sub.add_run(blocks[j]['text'])
                set_run_font(run_sub, '微软雅黑', Pt(16), bold=True)
                j += 1

            # Following preparation info lines (编制单位/编制日期)
            prep_first = True
            while j < n and blocks[j]['type'] == 'paragraph' and (
                '编制单位' in blocks[j]['text'] or '编制日期' in blocks[j]['text']
            ):
                p2 = doc.add_paragraph()
                p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
                # Push the first preparation info line to slightly below 2/3 of the page.
                if prep_first:
                    p2.paragraph_format.space_before = Cm(9.0)
                    prep_first = False
                add_rich_text(p2, blocks[j]['text'], '宋体', Pt(10.5))
                j += 1
            i = j
            continue

        # Page break handling
        if btype == 'page_break':
            add_page_break(doc)
            if in_title_page:
                in_title_page = False
                title_page_done = True
            i += 1
            continue

        # References detection (page break is already emitted by the \newpage marker)
        if btype == 'heading1' and block['text'] == '参考资料':
            in_references = True
            add_heading(doc, block['text'], 1, customer_name)
            i += 1
            continue

        # Headings
        if btype == 'heading1':
            add_heading(doc, block['text'], 1, customer_name)
            i += 1
            continue
        if btype == 'subtitle':
            para = doc.add_paragraph()
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = para.add_run(block['text'])
            set_run_font(run, '微软雅黑', Pt(16), bold=True)
            i += 1
            continue
        if btype == 'heading2':
            add_heading(doc, block['text'], 2, customer_name)
            i += 1
            continue
        if btype == 'heading3':
            add_heading(doc, block['text'], 3, customer_name)
            i += 1
            continue
        if btype == 'heading4':
            add_heading(doc, block['text'], 4, customer_name)
            i += 1
            continue

        # Table
        if btype == 'table':
            add_table(doc, block['headers'], block['rows'])
            i += 1
            continue

        # Image
        if btype == 'image':
            para = doc.add_paragraph()
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            if 'org_chart' in block['src'] or '组织架构' in block['alt']:
                chart_path = Path(__file__).parent / 'outputs' / 'org_chart.png'
                generate_org_chart(chart_path)
                run = para.add_run()
                run.add_picture(str(chart_path), width=Cm(14.0))
            i += 1
            continue

        # Numbered item
        if btype == 'numbered_item':
            para = doc.add_paragraph()
            para.paragraph_format.left_indent = Cm(0.74)
            para.paragraph_format.first_line_indent = Cm(-0.74)
            para.paragraph_format.line_spacing = Pt(22)
            # Add number manually to avoid cross-chapter continuation
            run = para.add_run(f"{block['num']}. ")
            set_run_font(run, '宋体', Pt(10.5))
            add_rich_text(para, block['text'], '宋体', Pt(10.5))
            i += 1
            continue

        # Bullet item
        if btype == 'bullet_item':
            para = doc.add_paragraph()
            para.paragraph_format.left_indent = Cm(0.74)
            para.paragraph_format.first_line_indent = Cm(-0.74)
            para.paragraph_format.line_spacing = Pt(22)
            run = para.add_run('• ')
            set_run_font(run, '宋体', Pt(10.5))
            add_rich_text(para, block['text'], '宋体', Pt(10.5))
            i += 1
            continue

        # Paragraph
        if btype == 'paragraph':
            para = doc.add_paragraph()
            para.paragraph_format.line_spacing = Pt(22)
            para.paragraph_format.first_line_indent = Cm(0.74)
            add_rich_text(para, block['text'], '宋体', Pt(10.5))
            i += 1
            continue

        i += 1

    doc.save(output_path)
    print(f'Saved: {output_path}')


if __name__ == '__main__':
    import json
    base = Path(__file__).resolve().parent
    profile = json.loads((base / 'customer_profile.json').read_text(encoding='utf-8'))
    customer_name = profile['客户名称']
    template_dir = base / 'unpacked_template'
    template_docx = base / 'outputs' / 'smartart_template.docx'

    # Ensure SmartArt template exists
    if not template_dir.exists() or not (template_dir / 'word' / 'diagrams' / 'data1.xml').exists():
        create_smartart_template.create_smartart_template(template_docx)
        # Unpack it for injection
        import subprocess
        subprocess.run([
            'python',
            str(Path(r'C:\Users\kingdee\.qoderwork\skills\docx\scripts\office\unpack.py')),
            str(template_docx),
            str(template_dir)
        ], check=True)

    generate_docx(
        base / 'outputs' / 'solution_report.md',
        base / 'outputs' / '金蝶星瀚系统升级解决方案报告.docx',
        customer_name
    )
    inject_smartart.inject_smartart(
        base / 'outputs' / '金蝶星瀚系统升级解决方案报告.docx',
        template_dir,
        base / 'outputs' / '金蝶星瀚系统升级解决方案报告.docx'
    )

    generate_docx(
        base / 'outputs' / 'proposal_report.md',
        base / 'outputs' / '金蝶星瀚系统升级立项报告.docx',
        customer_name
    )
    inject_smartart.inject_smartart(
        base / 'outputs' / '金蝶星瀚系统升级立项报告.docx',
        template_dir,
        base / 'outputs' / '金蝶星瀚系统升级立项报告.docx'
    )
