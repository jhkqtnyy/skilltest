"""Generate project organization chart image for docx reports."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from pathlib import Path

# Use Windows SimHei for Chinese characters
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def draw_box(ax, x, y, width, height, lines, fontsize=10):
    """Draw a rectangle with centered multi-line text."""
    rect = mpatches.FancyBboxPatch(
        (x - width / 2, y - height / 2),
        width, height,
        boxstyle="round,pad=0.02,rounding_size=0.02",
        facecolor='white',
        edgecolor='#333333',
        linewidth=1.2,
    )
    ax.add_patch(rect)

    # Center text vertically
    n_lines = len(lines)
    line_height = fontsize * 1.2 / 72  # inches; will be adjusted by axis limits
    # Use axis data coordinates for text; approximate center
    for idx, line in enumerate(lines):
        offset = (idx - (n_lines - 1) / 2) * (height * 0.25)
        ax.text(
            x, y - offset, line,
            ha='center', va='center',
            fontsize=fontsize,
            color='#333333',
            fontfamily='sans-serif',
        )


def draw_arrow(ax, x1, y1, x2, y2):
    """Draw a vertical arrow from (x1,y1) to (x2,y2)."""
    ax.annotate(
        '', xy=(x2, y2), xytext=(x1, y1),
        arrowprops=dict(arrowstyle='->', color='#333333', lw=1.2),
    )


def draw_horizontal_branches(ax, parent_x, parent_y, child_xs, child_y):
    """Draw a horizontal line from parent_x down to child_y, then vertical branches to each child."""
    # Vertical segment from parent down to child_y
    ax.plot([parent_x, parent_x], [parent_y, child_y], color='#333333', lw=1.2)
    # Horizontal segment across children
    if len(child_xs) > 1:
        ax.plot([min(child_xs), max(child_xs)], [child_y, child_y], color='#333333', lw=1.2)
    # Vertical segments to each child
    for cx in child_xs:
        ax.plot([cx, cx], [child_y, child_y + 0.02], color='#333333', lw=1.2)
        ax.plot([cx, cx], [child_y + 0.02, child_y], color='#333333', lw=1.2)
        # Small arrow head at child
        ax.annotate('', xy=(cx, child_y - 0.01), xytext=(cx, child_y + 0.02),
                    arrowprops=dict(arrowstyle='->', color='#333333', lw=1.2))


def generate_org_chart(output_path, dpi=200):
    """Generate a project organization chart PNG."""
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(10, 6), dpi=dpi)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.axis('off')
    ax.set_aspect('equal')

    # Layout constants
    box_w = 1.8
    box_h = 0.7
    level_y = [5.2, 4.0, 2.4, 0.8]

    # Level 0: 项目领导小组
    x0 = 5.0
    draw_box(ax, x0, level_y[0], box_w, box_h,
             ['项目领导小组', '客户方：XXX', '金蝶方：XXX'], fontsize=10)

    # Arrow to 项目经理
    draw_arrow(ax, x0, level_y[0] - box_h / 2, x0, level_y[1] + box_h / 2)

    # Level 1: 项目经理
    x1 = 5.0
    draw_box(ax, x1, level_y[1], box_w, box_h,
             ['项目经理', '客户方：XXX', '金蝶方：XXX'], fontsize=10)

    # Level 2: three groups
    groups = [
        ('财务组', '组长：XXX'),
        ('供应链组', '组长：XXX'),
        ('环境运维组', '组长：XXX'),
    ]
    group_xs = [2.0, 5.0, 8.0]
    for (gname, glead), gx in zip(groups, group_xs):
        draw_box(ax, gx, level_y[2], box_w, box_h,
                 [gname, glead], fontsize=10)

    # Branches from 项目经理 to groups
    draw_horizontal_branches(ax, x1, level_y[1] - box_h / 2, group_xs, level_y[2] + box_h / 2 + 0.15)

    # Level 3: placeholder sub-teams
    sub_teams = [
        ['XXX', 'XXX', 'XXX'],
        ['XXX', 'XXX'],
        ['XXX', 'XXX'],
    ]
    sub_box_w = 0.9
    for team_list, gx in zip(sub_teams, group_xs):
        n = len(team_list)
        if n == 1:
            sub_xs = [gx]
        elif n == 2:
            sub_xs = [gx - 0.6, gx + 0.6]
        elif n == 3:
            sub_xs = [gx - 1.0, gx, gx + 1.0]
        else:
            span = (n - 1) * 0.7
            sub_xs = [gx - span / 2 + i * 0.7 for i in range(n)]

        for sx, name in zip(sub_xs, team_list):
            draw_box(ax, sx, level_y[3], sub_box_w, box_h * 0.7,
                     [name], fontsize=9)

        # Branches from group to sub-teams
        draw_horizontal_branches(ax, gx, level_y[2] - box_h / 2, sub_xs, level_y[3] + box_h * 0.7 / 2 + 0.1)

    plt.tight_layout(pad=0.2)
    plt.savefig(output_path, format='png', dpi=dpi, bbox_inches='tight', pad_inches=0.1)
    plt.close(fig)
    return output_path


if __name__ == '__main__':
    out = Path(r'C:\Users\kingdee\.qoderwork\workspace\mr8khx892847j9gl\outputs\org_chart.png')
    generate_org_chart(out)
    print(f'Generated: {out}')
