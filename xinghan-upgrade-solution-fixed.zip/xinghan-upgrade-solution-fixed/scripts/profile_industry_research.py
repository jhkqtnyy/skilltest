# -*- coding: utf-8 -*-
"""Profile the 12-dimension industry research step.

Usage:
    python profile_industry_research.py --industry 光伏 \
        --old-product "金蝶云星瀚V5.0" \
        --pains "合并报表效率瓶颈" "供应链计划脱节" \
        --mode regular \
        --run

Without --run it only prints the query plan and risk analysis.
With --run it executes each search via the WebSearch MCP tool by shelling out
through this agent's own process (for timing purposes we rely on sequential
execution; the tool itself performs the actual search).
"""
import argparse
import json
import time
from pathlib import Path
from typing import List, Dict, Any, Callable


#: Subset of dimensions used in regular mode (fastest, most upgrade-decision-critical).
# Regular mode focuses on: policy compliance, EOL risk, competitive landscape,
# ROI quantification, pain-point validation, StarHan-specific proof, and accounting compliance.
REGULAR_DIMENSION_IDS = {1, 4, 5, 7, 8, 9, 11}

DIMENSIONS: List[Dict[str, Any]] = [
    {
        "id": 1,
        "name": "政策合规压力",
        "risk": "domestic",
        "queries": [
            "{industry} 数字化转型政策 2025 2026",
            "{industry} 国资监管新要求",
            "{industry} 信息系统建设管理办法",
            "电子凭证会计数据标准 财政部 落地",
            "{industry} 大额资金监管报送要求",
        ],
    },
    {
        "id": 2,
        "name": "行业标准强制要求",
        "risk": "domestic",
        "queries": [
            "{industry} 信息系统建设标准 最新",
            "{industry} 数据治理规范 2025",
            "{industry} 数字化成熟度评估标准",
            "{industry} ERP系统 验收标准",
            "{industry} 财务信息化 建设指南",
        ],
    },
    {
        "id": 3,
        "name": "行业龙头最佳实践",
        "risk": "domestic",
        "queries": [
            "{industry} 头部企业 财务数字化 最佳实践",
            "{industry} 500强 ERP升级 案例",
            "{industry} 龙头企业 智能化转型",
            "{industry} 标杆企业 业财一体化",
            "{industry} 领军企业 数字化战略",
        ],
    },
    {
        "id": 4,
        "name": "竞品/同行升级动态",
        "risk": "mixed",
        "queries": [
            "{industry} 金蝶星瀚 客户案例",
            "{industry} 用友 BIP 升级案例",
            "{industry} 浪潮 数字化 案例",
            "{industry} SAP S/4HANA 升级",
            "{industry} 财务共享中心 建设案例 2025",
        ],
    },
    {
        "id": 5,
        "name": "技术债务窗口期/EOL风险",
        "risk": "domestic",
        "queries": [
            "{old_product} 停止维护 公告",
            "{old_product} 停服 风险",
            "{old_product} 生命周期 结束",
            "ERP老系统 技术债务 风险",
            "{old_product} 安全漏洞",
        ],
    },
    {
        "id": 6,
        "name": "权威机构报告",
        "risk": "foreign",
        "queries": [
            "Gartner {industry} 数字化 魔力象限 2025",
            "IDC {industry} IT支出 报告 2025",
            "麦肯锡 {industry} 数字化转型 报告",
            "德勤 {industry} 财务智能化 趋势",
            "毕马威 {industry} 科技赋能 报告",
        ],
    },
    {
        "id": 7,
        "name": "ROI量化数据",
        "risk": "domestic",
        "queries": [
            "{industry} ERP升级 ROI 投资回报",
            "{industry} 数字化转型 效益 量化",
            "{industry} 财务共享中心 降本增效 数据",
            "ERP升级 效率提升 百分比 统计",
            "星瀚 客户 效益 数据",
        ],
    },
    {
        "id": 8,
        "name": "痛点行业共性分析",
        "risk": "domestic",
        "queries": [
            "{industry} {pain} 调研报告",
            "{industry} {pain} 白皮书",
            "{industry} {pain} 行业痛点",
            "{industry} 数字化转型 障碍 调研",
            "{industry} 效率瓶颈 根因分析",
        ],
    },
    {
        "id": 9,
        "name": "星瀚专属标杆案例",
        "risk": "domestic",
        "queries": [
            "金蝶星瀚 {industry} 成功案例",
            "金蝶AI星瀚 {industry} 客户",
            "{industry} 金蝶 星瀚 实施",
            "{industry} 金蝶云星瀚 效益",
            "星瀚 {industry} 财务共享 案例",
        ],
    },
    {
        "id": 10,
        "name": "信创/国产化要求",
        "risk": "domestic",
        "queries": [
            "{industry} 信创替代 要求 2025",
            "{industry} 国产化 ERP 政策",
            "{industry} 自主可控 信息系统",
            "信创目录 ERP 金蝶",
            "{industry} 安可工程 进展",
        ],
    },
    {
        "id": 11,
        "name": "新会计准则/财务合规",
        "risk": "domestic",
        "queries": [
            "新收入准则 系统要求 2025",
            "电子凭证会计数据标准 落地",
            "{industry} 会计准则变更 系统升级",
            "{industry} 财务报表 新规 要求",
            "电子发票 全面数字化 要求",
        ],
    },
    {
        "id": 12,
        "name": "行业数字化成熟度",
        "risk": "domestic",
        "queries": [
            "{industry} 数字化成熟度 报告 2025",
            "{industry} 智能财务 普及率",
            "{industry} ERP云化率 统计",
            "{industry} 财务机器人 RPA 使用率",
            "{industry} 业财一体化 覆盖率",
        ],
    },
]


def build_queries(industry: str, old_product: str, pains: List[str],
                  mode: str = "regular") -> List[Dict[str, Any]]:
    """Expand templates into concrete search queries.

    Args:
        mode: "regular" uses the upgrade-decision-critical dimension subset;
              "deep" uses all 12 dimensions.
    """
    primary_pain = pains[0] if pains else ""
    use_ids = REGULAR_DIMENSION_IDS if mode == "regular" else {d["id"] for d in DIMENSIONS}
    plan = []
    for dim in DIMENSIONS:
        if dim["id"] not in use_ids:
            continue
        dim_queries = []
        for tmpl in dim["queries"]:
            q = tmpl.format(industry=industry, old_product=old_product, pain=primary_pain)
            dim_queries.append(q)
        plan.append({
            "dimension_id": dim["id"],
            "dimension_name": dim["name"],
            "risk": dim["risk"],
            "queries": dim_queries,
        })
    return plan


def execute_plan(plan: List[Dict[str, Any]], searcher: Callable[[str], Any],
                 timeout_per_query: float = 30.0,
                 mode: str = "regular") -> Dict[str, Any]:
    """Run each query through the provided searcher and record timing."""
    results = []
    dimension_names = [d["dimension_name"] for d in plan]
    total_start = time.time()
    for dim in plan:
        dim_start = time.time()
        dim_queries = []
        for q in dim["queries"]:
            q_start = time.time()
            status = "ok"
            try:
                # The searcher itself should enforce the timeout if it can.
                searcher(q)
            except Exception as e:
                status = f"error: {type(e).__name__}: {e}"
            q_elapsed = round(time.time() - q_start, 3)
            dim_queries.append({
                "query": q,
                "elapsed_seconds": q_elapsed,
                "status": status,
                "slow": q_elapsed >= timeout_per_query * 0.7,
                "timeout": q_elapsed >= timeout_per_query,
            })
        dim_elapsed = round(time.time() - dim_start, 3)
        results.append({
            "dimension_id": dim["dimension_id"],
            "dimension_name": dim["dimension_name"],
            "risk": dim["risk"],
            "elapsed_seconds": dim_elapsed,
            "queries": dim_queries,
        })
    total_elapsed = round(time.time() - total_start, 3)
    return {
        "mode": mode,
        "dimensions_used": dimension_names,
        "total_elapsed_seconds": total_elapsed,
        "query_count": sum(len(d["queries"]) for d in plan),
        "dimensions": results,
    }


def print_report(report: Dict[str, Any]) -> None:
    mode = report.get("mode", "regular")
    dim_names = report.get("dimensions_used", [])
    all_names = [d["name"] for d in DIMENSIONS]
    skipped = [n for n in all_names if n not in dim_names]
    print(f"\n研究模式：{mode}")
    print(f"使用维度（{len(dim_names)} 个）：{', '.join(dim_names)}")
    if skipped:
        print(f"跳过维度（{len(skipped)} 个）：{', '.join(skipped)}")
    print(f"总计 {report['query_count']} 次搜索，耗时 {report['total_elapsed_seconds']:.1f} 秒\n")
    slow_queries = []
    timeouts = []
    for dim in report["dimensions"]:
        print(f"维度 {dim['dimension_id']:2d}. {dim['dimension_name']} "
              f"[{dim['risk']}] - {dim['elapsed_seconds']:.1f}s")
        for q in dim["queries"]:
            flag = ""
            if q["timeout"]:
                flag = " [TIMEOUT]"
                timeouts.append(q)
            elif q["slow"]:
                flag = " [SLOW]"
                slow_queries.append(q)
            print(f"    {q['elapsed_seconds']:5.2f}s {q['status']}{flag} | {q['query']}")
    print("\n--- 慢查询分析 ---")
    if timeouts:
        print(f"超时/接近超时查询 {len(timeouts)} 条：")
        for q in timeouts:
            print(f"  {q['elapsed_seconds']:.1f}s | {q['query']}")
    else:
        print("无超时查询")
    if slow_queries:
        print(f"\n较慢查询 {len(slow_queries)} 条（超过阈值的70%）：")
        for q in slow_queries:
            print(f"  {q['elapsed_seconds']:.1f}s | {q['query']}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--industry", default="光伏")
    parser.add_argument("--old-product", default="金蝶云星瀚V5.0")
    parser.add_argument("--pains", nargs="+", default=[
        "合并报表效率瓶颈",
        "供应链计划与执行脱节",
        "海外费用报销分散",
        "版本生命周期与合规风险叠加",
        "系统性能制约业务扩张",
    ])
    parser.add_argument("--run", action="store_true",
                        help="Actually execute searches (requires a searcher implementation)")
    parser.add_argument("--mode", choices=["regular", "deep"], default="regular",
                        help="regular=升级决策关键维度子集（默认，约35次搜索）; deep=完整12维度（约60次搜索）")
    parser.add_argument("--output", default="industry_research_profile.json")
    parser.add_argument("--timeout", type=float, default=30.0)
    args = parser.parse_args()

    plan = build_queries(args.industry, args.old_product, args.pains, mode=args.mode)

    if not args.run:
        all_names = [d["name"] for d in DIMENSIONS]
        used_names = [d["dimension_name"] for d in plan]
        skipped_names = [n for n in all_names if n not in used_names]
        print(f"研究模式：{args.mode}")
        print(f"使用维度（{len(used_names)} 个）：{', '.join(used_names)}")
        if skipped_names:
            print(f"跳过维度（{len(skipped_names)} 个）：{', '.join(skipped_names)}")
        print("\n查询计划（不执行搜索）：")
        for dim in plan:
            print(f"\n维度 {dim['dimension_id']}: {dim['dimension_name']} [risk={dim['risk']}]")
            for q in dim["queries"]:
                print(f"  - {q}")
        foreign = [q for dim in plan for q in dim["queries"] if dim["risk"] == "foreign"]
        print(f"\n风险提示：包含 {len(foreign)} 条涉外/英文查询，容易因网络或源站超时：")
        for q in foreign:
            print(f"  - {q}")
        return

    # Placeholder searcher: in the real skill this would call the WebSearch MCP tool.
    # For local testing without the tool we just simulate network latency.
    def dummy_searcher(q: str) -> None:
        time.sleep(0.01)

    report = execute_plan(plan, dummy_searcher, timeout_per_query=args.timeout, mode=args.mode)
    Path(args.output).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print_report(report)
    print(f"\n详细结果已保存：{args.output}")


if __name__ == "__main__":
    main()
