"""Create a Word document with a SmartArt organization chart using COM automation."""
import win32com.client as win32
from pathlib import Path


def find_org_chart_layout(word_app):
    """Find the index of the 'Organization Chart' SmartArt layout."""
    layouts = word_app.SmartArtLayouts
    for i in range(1, layouts.Count + 1):
        layout = layouts.Item(i)
        name = layout.Name
        category = layout.Category
        # Organization chart layouts typically contain 'Organization' in name or category
        if 'Organization' in name or 'Organization' in category or '组织架构' in name or '组织' in name:
            print(f'Index {i}: {name} / {category}')
            return i
    # Fallback: return first layout
    return 1


def create_smartart_template(output_path):
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    word = win32.DispatchEx('Word.Application')
    word.Visible = False
    word.DisplayAlerts = False

    doc = word.Documents.Add()

    # Find organization chart layout
    layout_index = find_org_chart_layout(word)
    print(f'Using layout index: {layout_index}')

    # Add SmartArt
    # Page width in points: A4 = 595.35 pt, usable width with 3.17cm margins ~ 445 pt
    shape = doc.Shapes.AddSmartArt(
        word.SmartArtLayouts.Item(layout_index),
        Left=50,
        Top=50,
        Width=445,
        Height=350
    )

    smart_art = shape.SmartArt

    # Clear default nodes and build our structure
    # SmartArt has a AllNodes collection
    nodes = smart_art.AllNodes

    # The layout may have a root node already; we'll try to use it or add nodes
    # For organization chart, we need:
    # Root: 项目领导小组
    #   -> 项目经理
    #        -> 财务组
    #             -> XXX, XXX, XXX
    #        -> 供应链组
    #             -> XXX, XXX
    #        -> 环境运维组
    #             -> XXX, XXX

    # Build from root
    root = smart_art.AllNodes.Item(1)
    root.TextFrame2.TextRange.Text = '项目领导小组\n客户方：XXX\n金蝶方：XXX'

    # Add child to root: 项目经理
    pm_node = root.AddNode(2)  # msoSmartArtNodeTypeDefault = 1, msoSmartArtNodeTypeAssistant = 2
    pm_node.TextFrame2.TextRange.Text = '项目经理\n客户方：XXX\n金蝶方：XXX'

    # SmartArt node position/type constants
    # MsoSmartArtNodePosition: Default=1, After=2, Before=3, Above=4, Below=5
    NODE_BELOW = 5   # msoSmartArtNodeBelow
    NODE_AFTER = 2   # msoSmartArtNodeAfter
    NODE_DEFAULT = 1 # msoSmartArtNodeTypeDefault

    # Add three groups as peers under 项目经理
    groups = [
        ('财务组', '组长：XXX', ['XXX', 'XXX', 'XXX']),
        ('供应链组', '组长：XXX', ['XXX', 'XXX']),
        ('环境运维组', '组长：XXX', ['XXX', 'XXX']),
    ]
    prev_group = None
    for idx, (g_name, g_lead, children) in enumerate(groups):
        if idx == 0:
            group_node = pm_node.AddNode(NODE_BELOW, NODE_DEFAULT)
        else:
            group_node = prev_group.AddNode(NODE_AFTER, NODE_DEFAULT)
        prev_group = group_node
        group_node.TextFrame2.TextRange.Text = f'{g_name}\n{g_lead}'
        prev_child = None
        for cidx, child in enumerate(children):
            if cidx == 0:
                child_node = group_node.AddNode(NODE_BELOW, NODE_DEFAULT)
            else:
                child_node = prev_child.AddNode(NODE_AFTER, NODE_DEFAULT)
            prev_child = child_node
            child_node.TextFrame2.TextRange.Text = child

    doc.SaveAs(str(output_path))
    doc.Close()
    word.Quit()
    print(f'Saved SmartArt template: {output_path}')


if __name__ == '__main__':
    out = Path(r'C:\Users\kingdee\.qoderwork\workspace\mr8khx892847j9gl\outputs\smartart_template.docx')
    create_smartart_template(out)
