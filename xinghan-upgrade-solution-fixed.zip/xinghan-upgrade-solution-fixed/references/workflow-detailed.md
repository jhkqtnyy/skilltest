# 详细工作流程

## 流程概览

```
输入验证 → 问卷解析 → 行业研究 → 知识库检索 → 报告生成
```

各步骤串行执行，前一步输出作为后一步输入。

---

## Step 1：输入验证

**输入**：用户提供的问卷内容（文本 / 文件 / 对话形式）
**输出**：验证通过的 `customer.json` 或缺失项反馈

执行动作：
1. 解析用户输入，提取问卷字段
2. 对照 7 项必填清单逐项检查（详见 `references/input-validation.md`）
3. 关键项缺失时向用户反馈并等待补充
4. 验证通过后写入 `customers/current/customer.json`

---

## Step 2：问卷解析

**输入**：`customers/current/customer.json`
**输出**：结构化客户画像 `customer_profile.yaml`

提取字段：
- 客户基本信息（名称、行业、规模、地域）
- 当前系统信息（版本、模块、使用年限、补丁级别）
- 痛点列表（按业务域分类，标注优先级）
- 目标模块清单（升级范围）
- 时间线与预算约束
- 关键干系人及决策链

---

## Step 3：行业研究

**输入**：`customer_profile.yaml` 中的行业字段
**输出**：行业趋势报告 `industry_research.md`

默认执行**常规模式**（7 个核心维度），可选**深度模式**（完整 12 维度）。具体维度与模式切换规则详见 `references/industry-researcher.md`。

常规模式覆盖的 7 个维度：

| 维度 | 搜索目标 |
|------|---------|
| ① 政策合规压力 | 行业监管政策、合规要求、Deadline |
| ④ 竞品/同行升级动态 | 同行业 ERP 升级率、竞品案例 |
| ⑤ 技术债务窗口期/EOL风险 | 老产品维护状态、停服风险 |
| ⑦ ROI量化数据 | 升级效率提升、成本降低数据 |
| ⑧ 痛点行业共性分析 | 客户痛点在行业内的普遍性 |
| ⑨ 星瀚专属标杆案例 | 金蝶星瀚同行业成功案例 |
| ⑪ 新会计准则/财务合规 | 新准则、电子凭证、财务合规要求 |

深度模式额外补充：② 行业标准强制要求、③ 行业龙头最佳实践、⑥ 权威机构报告、⑩ 信创/国产化要求、⑫ 行业数字化成熟度。

搜索策略、关键词模板与结果整合规则 → `references/industry-researcher.md`

---

## Step 4：知识库检索

**输入**：客户痛点列表 + 目标模块清单
**输出**：匹配的文档段落、FAQ 答案、案例列表 `kb_retrieval_results.json`

执行 4 层检索：

| 层级 | 动作 | 数据源 |
|------|------|--------|
| Layer 1 | 按模块 ID 过滤相关文档 | `knowledge-base/index.yaml` |
| Layer 2 | 读取相关文档的 `summary.md` 快速判断内容相关性 | 各目录 `summary.md` |
| Layer 3 | 读取完整 Markdown 文档，提取与痛点匹配的段落 | `knowledge-base/references/**/*.md` |
| Layer 4 | 语义分块匹配，获取最细粒度的相关内容 | `knowledge-base/chunks/*.json` |

检索完成后：
- 将匹配结果与客户痛点做映射
- 从 `knowledge-base/references/cases.md` 匹配可信度 ≥60% 的行业案例
- 从 `knowledge-base/faq/faq.md` 检索与痛点相关的 FAQ 条目
- 所有结果标注来源文档 ID 和位置

知识库检索详细配置 → `references/knowledge-keeper.md`

---

## Step 5：报告生成

**输入**：行业研究结果 + 知识库检索结果 + 客户画像
**输出**：Markdown 报告 `report/solution.md` + Word 文档 `report/solution.docx`

执行动作：
1. 内容生成 Agent 按 `references/output-spec.md` 的章节结构撰写报告
2. 每个章节引用对应的检索结果，标注 HTML 来源注释
3. 组装完整 Markdown 文件
4. 转换生成 docx，过滤所有 HTML 注释
5. 自检：检查来源注释完整性、格式一致性、敏感信息泄露

报告撰写详细规范 → `references/content-writer.md`

---

## 执行编排与耗时统计

为保証每次生成的 Word 格式一致，Step 5 必须通过统一脚本执行：

```bash
python3 scripts/run_workflow.py --workspace <workspace-path>
```

脚本内部调用链：
1. `generate_reports.py`：生成 `solution_report.md` 与 `proposal_report.md`；
2. `md2docx.py`：转换为 docx 并通过 `inject_smartart.py` 注入 Word 原生 SmartArt。

脚本会为每个阶段计时并写入 `<workspace>/workflow_timing.json`：

| 字段 | 说明 |
|------|------|
| `started_at` | 工作流开始时间 |
| `stages[].name` | 阶段名称（input_validation / industry_research / kb_retrieval / report_generation / docx_conversion） |
| `stages[].elapsed_seconds` | 该阶段耗时 |
| `finished_at` | 各阶段累加结束时间 |

**注意**：`industry_research` 阶段默认读取缓存的 `industry_research.json`。如需测量真实 Web 搜索耗时，请先运行行业研究 Agent 生成该文件（默认常规模式，约 35 次搜索；可选深度模式，约 50-60 次搜索），或单独使用 `scripts/profile_industry_research.py --mode {regular,deep}` 进行 profiling。

---

## Token 优化策略

各阶段 Token 预算分配建议：

| 阶段 | 预算 | 优化策略 |
|------|------|---------|
| 输入验证 | ~500 tokens | 仅处理结构化字段，不展开分析 |
| 问卷解析 | ~1K tokens | 提取关键字段，生成结构化 YAML |
| 行业研究 | ~5-10K tokens（常规）/ ~8-15K tokens（深度） | 常规模式 7 维度、深度模式 12 维度；每维度仅保留 Top-3 结果 |
| 知识库检索 | ~5-10K tokens | Layer 1-2 预过滤，仅对高度相关文档执行 Layer 3-4 |
| 报告生成 | ~10-20K tokens | 按章节分批次生成，避免单次调用超长输出 |

**优化原则**：
- 行业研究阶段优先使用搜索摘要而非全文，仅对关键维度展开详细内容
- 知识库检索时，Layer 3 全文读取仅针对 Layer 2 筛选后的高相关文档（≤5 份）
- 报告生成时，将行业研究结论和知识库检索结果作为上下文注入，避免重复检索
