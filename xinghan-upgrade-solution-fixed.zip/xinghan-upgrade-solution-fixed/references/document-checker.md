# 文档格式检查助手

每次生成Word文档后，必须执行以下检查流程。发现任何**P0/P1**级别问题，必须修复后重新生成。

## 检查执行时机

在Markdown→Word转换完成后立即执行，在交付给用户之前。

---

## P0 级错误（必须修复，否则文档不可用）

| # | 检查项 | 检查方法 | 修复方式 |
|---|--------|---------|---------|
| 1 | 标题层级错乱（如`### 1.3### 1.3`重复） | `grep -n '###.*###'` | 删除重复部分 |
| 2 | 章节序号跳号（1.1→1.2→1.4） | 遍历Heading检查连续性 | 补充缺失章节或修正编号 |
| 3 | Markdown→Word转换失败（文件损坏/打不开） | 尝试用Document()加载 | 重新执行转换脚本 |
| 4 | 商务报价金额未留空 | 检查表格对应单元格text | 清空单元格内容 |
| 5 | 粗体标记`**`残留为`*`字符 | `grep -n '\*' 报告.md`（排除表格行） | 检查粗体解析逻辑 |

## P1 级错误（必须修复，影响专业度）

| # | 检查项 | 检查方法 | 修复方式 |
|---|--------|---------|---------|
| 6 | 四级标题（H4）为斜体 | 检查Heading 4段落的run.font.italic | 设置`run.font.italic = False` |
| 7 | 正文中出现`*`字符 | 全文搜索`*`（排除`**`粗体标记） | 替换或修正格式标记 |
| 8 | 章节标题带"表格"二字（如"组织范围表格"） | `grep -n '表格'` | 删除"表格"二字 |
| 9 | 标题页内容多余（出现客户名称/方案版本等） | 检查标题页段落 | 只保留标题+编制单位+编制日期 |
| 10 | 参考资料不在新页 | 检查参考资料前的分页符 | 添加`pageBreakBefore` |
| 11 | 目录/大纲缺失 | 检查是否有TOC字段 | 在标题页后添加目录 |
| 12 | 编号列表跨章连续（如第六章从10开始） | 检查各章编号是否从1开始 | 使用`numbered_list`类型或手动前缀 |
| 13 | 模板说明文字残留（`<!--`注释、`>`说明） | `grep -n '<!--\|^>'` | 删除所有HTML注释和说明文字 |
| 14 | 来源标注格式错误（正文用`[n]`而非上标） | 检查正文是否有`[n]`（非参考资料行） | 替换为上标`ⁿ` |
| 15 | 分页位置错误（如六、下一步行动前分页） | 检查`
ewpage`位置 | 删除错误位置的分页符 |

## P2 级错误（建议修复，优化体验）

| # | 检查项 | 检查方法 |
|---|--------|---------|
| 16 | 字体未逐run设置（依赖默认样式） | 遍历所有runs检查rFonts.eastAsia |
| 17 | 表格表头无深蓝背景#2F5496 | 检查第一行cells的shd.fill |
| 18 | 页眉缺失或格式错误 | 检查header段落 |
| 19 | 段落过长（>120字） | 统计每段中文字符数 |
| 20 | 空行过多（连续3+空行） | 检查段落间空行数量 |

---

## 常见错误速查表

```
问题                              检查命令
─────────────────────────────────────────────────────────
1.3重复#号          grep -n '###.*###' 报告.md
章节标题带"表格"    grep -n '表格' 报告.md
正文有*残留         grep -n '\*' 报告.md | grep -v '^.*|' | grep -v '\*\*'
参考资料前多空白页  grep -n '\\newpage' 报告.md（检查数量>2）
来源格式[n]          grep -n '\[\d\+\]' 报告.md | grep -v '^\[\d\+\]'
大纲/目录缺失        grep -n '大纲\|目录\|TOC\|tableofcontent' 报告.md
模板注释残留         grep -n '<!--' 报告.md
```

## 检查脚本（Python）

```python
from docx import Document
import re

def check_document(doc_path, report_type='solution'):
    """
    检查Word文档质量。
    report_type: 'solution' | 'proposal'
    返回: (errors列表, warnings列表)
    """
    doc = Document(doc_path)
    errors = []
    warnings = []
    all_text = '\n'.join([p.text for p in doc.paragraphs])
    
    # P0: 标题层级检查
    for p in doc.paragraphs:
        if '###' in p.text and p.text.count('###') > 1:
            errors.append(f"P0: 标题重复#号: {p.text[:50]}")
    
    # P1: H4斜体
    for p in doc.paragraphs:
        if p.style and 'Heading 4' in p.style.name:
            for run in p.runs:
                if run.font.italic:
                    errors.append(f"P1: H4斜体: {p.text[:30]}")
                    break
    
    # P1: 正文*残留
    for p in doc.paragraphs:
        clean = re.sub(r'\*\*.*?\*\*', '', p.text)
        if '*' in clean and not p.text.startswith('|') and not p.text.startswith('•'):
            errors.append(f"P1: *残留: {p.text[:50]}")
    
    # P1: 标题带"表格"
    for p in doc.paragraphs:
        if p.style and 'Heading' in p.style.name and '表格' in p.text:
            errors.append(f"P1: 标题带'表格': {p.text}")
    
    # P1: 来源格式
    for p in doc.paragraphs:
        if re.search(r'\[\d+\]', p.text) and not p.text.strip().startswith('['):
            errors.append(f"P1: 来源格式[n]非上标: {p.text[:50]}")
    
    return errors, warnings
```

## 修复优先级

```
P0 错误 → 立即修复 → 重新生成Word
P1 错误 → 立即修复 → 重新生成Word
P2 警告 → 记录在案 → 下次迭代修复
```

**规则**：任何P0/P1错误未修复的文档，禁止交付给用户。