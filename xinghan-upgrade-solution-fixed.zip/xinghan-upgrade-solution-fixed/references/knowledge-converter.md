# 知识库自动转换规范

## 职责
知识库管家Agent在收到用户上传的原始文档后，自动将其转换为带知识溯源的Markdown格式。

## 支持转换的格式

| 格式 | 扩展名 | 处理方式 | 输出 |
|------|--------|----------|------|
| PowerPoint | .ppt / .pptx | 提取每页文本+备注 | .md（每页一个二级标题） |
| PDF | .pdf | 提取文本层（OCR提示扫描版） | .md |
| Word | .doc / .docx | 提取段落+表格 | .md |
| Excel | .xls / .xlsx | 提取Sheet内容 | .md |
| Markdown | .md | 直通，检查溯源标记 | .md |

## 转换流程

```
用户上传文件
    ↓
┌───────────────────┐
│ ① 识别文件类型    │ ← 根据扩展名判断
└─────────┬───────────┘
          ↓
┌───────────────────┐
│ ② 提取原始内容    │ ← 按格式类型解析
│    (文本/表格/页) │
└─────────┬───────────┘
          ↓
┌───────────────────┐
│ ③ 生成完整 .md    │ → [原始文件名].md
│    (含溯源头部)    │    正文带页码溯源注释
└─────────┬───────────┘
          ↓
┌───────────────────┐
│ ④ 生成 summary.md │ → summary.md
│    (Layer 2摘要)   │    核心功能/价值/适用场景
└─────────┬───────────┘
          ↓
┌───────────────────┐
│ ⑤ 更新 index.yaml │ → 自动追加条目
│    (Layer 1索引)   │    更新page_count、key_features
└───────────────────┘
```

## 完整 .md 文件格式规范

### 头部 YAML Frontmatter（必须）

```yaml
---
source_file: "金蝶AI星瀚新品发布介绍.pptx"
source_path: "knowledge-base/references/version-guides/starhan-release/"
converted_at: "2026-05-13"
converted_by: "知识库管家Agent"
file_type: "pptx"
page_count: 27
version: "星瀚2024"
---
```

**字段说明**：
| 字段 | 必填 | 说明 |
|------|------|------|
| source_file | ✅ | 原始文件名（含扩展名） |
| source_path | ✅ | 在knowledge-base中的存放路径 |
| converted_at | ✅ | 转换时间戳（ISO 8601） |
| converted_by | ✅ | 转换执行者标识 |
| file_type | ✅ | 原始文件类型（pptx/pdf/docx/xlsx） |
| page_count | 可选 | 原始文件页数/幻灯片数 |
| version | 可选 | 文档对应的产品版本 |
| key_features | 可选 | 核心功能摘要（数组） |
| tags | 可选 | 标签数组 |

### 正文知识溯源标记

**每条内容必须标注来源**：

```markdown
# 金蝶AI星瀚新品发布介绍

## 1. 产品概述
<!-- 知识溯源：第1页 - 产品定位 -->
金蝶AI星瀚是基于云原生架构的新一代企业级PaaS平台...

## 2. 核心能力
<!-- 知识溯源：第2-5页 - 核心特性概览 -->
### 2.1 AI智能助手
<!-- 知识溯源：第3页 - AI助手介绍 -->
支持自然语言交互，可自动识别业务意图...

### 2.2 智能核算
<!-- 知识溯源：第4页 - 智能核算 -->
通过AI自动完成凭证生成、科目匹配...
```

**标记规则**：
- PPT文件：`<!-- 知识溯源：第X页 - [页面主题] -->`
- PDF文件：`<!-- 知识溯源：第X页 - [章节标题] -->`
- Word文件：`<!-- 知识溯源：章节X.X - [章节名] -->`
- Excel文件：`<!-- 知识溯源：Sheet"XXX" - 第X行 -->`

## summary.md 生成规范

在每个目录下自动生成 `summary.md`，用于Layer 2快速检索。

```markdown
---
source_dir: "knowledge-base/references/version-guides/starhan-release/"
summarized_at: "2026-05-13"
summarized_by: "知识库管家Agent"
document_count: 2
---

# 星瀚版本升级指南摘要

## 文档清单
- [金蝶AI星瀚新品发布介绍.md](金蝶AI星瀚新品发布介绍.md) - 27页
- [AI星瀚特性白皮书.md](AI星瀚特性白皮书.md) - 40页

## 核心功能汇总

### 产品定位
<!-- 知识溯源：来自 金蝶AI星瀚新品发布介绍.md 第1页 -->
金蝶AI星瀚是金蝶面向大型企业的新一代数字化平台...

### 核心特性
| 特性 | 说明 | 来源 |
|------|------|------|
| AI智能助手 | 自然语言交互、业务意图识别 | 新品发布介绍.md 第3页 |
| 智能核算 | AI自动凭证生成、科目匹配 | 新品发布介绍.md 第4页 |
| 云原生架构 | 弹性扩展、高可用 | 新品发布介绍.md 第5页 |

## 适用场景
- 大型企业ERP升级
- 多组织集团财务
- 信创国产化替代

## 升级价值
- 效率提升：报表自动化率提升90%
- 成本降低：运维人力减少50%
- 合规保障：满足电子凭证标准
```

**summary.md 生成规则**：
1. 提取完整.md中的核心功能点（每个模块5-10个）
2. 提取价值亮点（效率/成本/合规）
3. 提取适用场景
4. 所有内容标注来源（指向完整.md的具体页码）
5. 字数控制在500-1500字（Layer 2标准）

## index.yaml 自动更新规则

当有新文件转换完成时，自动追加到 `index.yaml`：

```yaml
documents:
  - id: starhan-release-2026-05-13
    name: 金蝶AI星瀚新品发布介绍
    path: references/version-guides/starhan-release/
    type: version-guide
    tags: [星瀚, AI星瀚, 新品发布, 核心特性]
    summary: "星瀚最新版本的发布特性、核心能力、技术架构升级"
    page_count: 27
    key_features:
      - AI智能助手
      - 智能核算
      - 云原生架构
      - 信创适配
    converted_at: "2026-05-13"
    source_file: "金蝶AI星瀚新品发布介绍.pptx"
```

**更新规则**：
- 新文件：追加新条目
- 同名文件：更新converted_at和page_count
- 删除文件：从index.yaml移除对应条目（需手动确认）

## 目录分类规则（三层架构）

用户上传文件时，Agent根据文件名/内容自动分类到对应层级：

### 第一层：苍穹（PaaS底座）
| 文件名特征 | 推荐目录 | 类型标记 |
|------------|----------|----------|
| 含"苍穹""PaaS""Agent开发""云原生" | `references/cangqiu/[sub-dir]/` | platform-guide |
| 含"应用开发""集成平台""数据分析" | `references/cangqiu/[sub-dir]/` | platform-guide |

### 第二层：星瀚（SaaS应用层）
| 文件名特征 | 推荐目录 | 类型标记 |
|------------|----------|----------|
| 含"发布""新品""版本""特性""版本策略" | `references/starhan/version-guides/[version-name]/` | version-guide |
| 含"总账""财务""GL" | `references/starhan/module-docs/finance/gl/` | module-doc |
| 含"资金""司库""Treasury" | `references/starhan/module-docs/finance/treasury/` | module-doc |
| 含"费用""报销""Expense" | `references/starhan/module-docs/finance/expense/` | module-doc |
| 含"供应链""采购""销售""库存" | `references/starhan/module-docs/scm/` | module-doc |
| 含"人力""HR""薪酬""绩效" | `references/starhan/module-docs/hr/` | module-doc |

### 第三层：AI套件（AI能力层）
| 文件名特征 | 推荐目录 | 类型标记 |
|------------|----------|----------|
| 含"AI套件""企业管理AI""AI EBC" | `references/ai-suite/solution-docs/` | solution-doc |
| 含"智能体""Agent""大模型""RAG" | `references/ai-suite/ai-capability/` | ai-capability |

### 模板/标准文件
| 文件名特征 | 推荐目录 | 类型标记 |
|------------|----------|----------|
| 含"模板""母版""标准方案" | `templates/ppt/` | template |
| 含"解决方案""方案""升级方案" | `references/starhan/solution-docs/` 或 `references/ai-suite/solution-docs/` | solution-doc |

**无法自动分类时**：提示用户确认存放路径。

## Token消耗预估

| 原始文件 | 转换后 .md 大小 | summary.md 大小 |
|----------|----------------|-----------------|
| 30页PPT | ~3-5K tokens | ~800 tokens |
| 100页PPT | ~10-15K tokens | ~1.5K tokens |
| 50页PDF | ~5-8K tokens | ~1K tokens |

**策略**：完整.md用于Layer 3精准检索，summary.md用于Layer 2快速判断。

## 示例：完整转换过程

**用户上传**：`金蝶AI星瀚新品发布介绍.pptx` (27页)

**Agent执行**：
1. 识别为PPT，存放路径：`knowledge-base/references/version-guides/starhan-release/`
2. 提取每页文本，生成 `金蝶AI星瀚新品发布介绍.md`
3. 生成 `summary.md`
4. 更新 `index.yaml`

**输出文件**：
```
knowledge-base/references/version-guides/starhan-release/
├── 金蝶AI星瀚新品发布介绍.pptx  ← 原始文件（保留）
├── 金蝶AI星瀚新品发布介绍.md    ← 转换后完整文档
└── summary.md                    ← Layer 2摘要
```

## 关键约束

- ✅ 原始文件保留不删除（作为源文件存档）
- ✅ 每个.md必须带YAML frontmatter头部
- ✅ 每条核心内容必须带 `<!-- 知识溯源 -->` 注释
- ✅ summary.md 字数控制在500-1500字
- ✅ 自动更新index.yaml，保持索引同步
- ❌ 禁止丢失原始文件中的表格结构（转为Markdown表格）
- ❌ 禁止合并多页内容丢失页码信息

## 客户信息脱敏规则

**识别范围**：
- 文档中出现的客户企业名称（含全称、简称、品牌名）
- 客户联系人的真实姓名
- 客户内部项目代号（如非公开信息）
- 客户敏感数据（如具体金额、具体人数，保留描述但脱敏数值）

**脱敏方式**：
| 信息类型 | 脱敏方法 | 示例 |
|----------|----------|------|
| 客户企业名称 | 拼音首字母缩写 | "招商局集团" → "ZSJ集团" |
| 客户简称 | 拼音首字母缩写 | "华为" → "HW" |
| 联系人姓名 | 首字母+某 | "张三" → "Z某" |
| 具体金额 | 保留描述，数值模糊化 | "总投资5000万" → "总投资约XX万元" |
| 具体人数 | 保留描述，数值模糊化 | "财务部20人" → "财务部约XX人" |

**例外**：如果文档本身就是公开案例（如金蝶官网已发布的授权案例），保留原名称但标注来源。

## 敏感内容过滤规则

**敏感标识词**（识别到以下任一标识时，该段/该页内容不记录入知识库）：

| 标识词 | 处理方式 |
|--------|----------|
| "绝密信息""严禁泄露""机密""Secret" | 整页跳过，md中标注"⚠️ 敏感内容已跳过" |
| "内部使用""Internal Use Only""不对外" | 整段/整页跳过 |
| "不适合给客户""客户勿看""售前内部" | 整段/整页跳过 |
| "价格表""报价单""折扣""返点" | 整段跳过（除非脱敏为区间描述） |
| 未授权的客户内部截图（含客户Logo/名称） | 跳过该截图对应的内容段落 |

**过滤后的md格式**：
```markdown
## 第X页 - （敏感内容已跳过）
<!-- 知识溯源：第X页 - 原PDF标注"绝密信息严禁泄露"，根据知识库规范，敏感内容不记录 -->

> ⚠️ **敏感内容处理**：该页原标注"绝密信息严禁泄露"，根据知识库规范，敏感内容不记录。已跳过该页内容。
```

## 升级路径关联说明

**知识库三层架构对应关系**：

| 层级 | 产品 | 升级后获得的能力 |
|------|------|------------------|
| PaaS底座 | 苍穹V8.0 | Agent开发平台、云原生架构、低代码开发、集成平台、数据分析 |
| SaaS应用层 | 星瀚V8.0+ | 财务、供应链、人力等SaaS应用（已发布在苍穹底座上） |
| AI能力层 | AI套件 | 企业管理AI（AI EBC）、智能体、大模型、RAG、多模态 |

**生成方案时的引用规则**：
- 客户从EAS/K3升级时，默认推荐"苍穹+星瀚"组合升级
- 知识库检索时，同时检索`cangqiu/`（苍穹底座能力）和`starhan/`（星瀚应用能力）
- 如果客户有AI需求，额外检索`ai-suite/`（AI套件能力）
- Markdown报告中必须明确区分：哪些是苍穹底座能力（PaaS）、哪些是星瀚应用能力（SaaS）

---

*知识库自动转换规范 v1.1*
*最后更新：2026-05-13*
