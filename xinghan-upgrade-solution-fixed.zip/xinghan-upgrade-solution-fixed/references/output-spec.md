---

## Word文档格式规范（强制执行）

> 本规范描述的是**最终Word文档的格式要求**。Agent生成Markdown后，必须通过python-docx或类似工具转换为Word，并严格按以下要求设置字体。
> **注意**：不能依赖Word默认样式或Pandoc自动转换，必须显式设置每个元素的字体属性。

### 字体设置方式（必须显式设置）

python-docx中，必须通过以下方式显式设置字体，**不能依赖默认值**：

```python
# 一级标题（Heading 1）
heading1_run.font.name = '微软雅黑'
heading1_run.font.size = Pt(18)  # 小二 = 18pt
heading1_run.font.bold = True
heading1_run.font.color.rgb = RGBColor(0, 0, 0)
# 设置东亚字体（中文字符）
rpr = heading1_run._element.get_or_add_rPr()
rFonts = rpr.find(qn('w:rFonts'))
if rFonts is None:
    rFonts = OxmlElement('w:rFonts')
    rpr.insert(0, rFonts)
rFonts.set(qn('w:eastAsia'), '微软雅黑')

# 二级标题（Heading 2）
heading2_run.font.name = '微软雅黑'
heading2_run.font.size = Pt(16)  # 三号 = 16pt
heading2_run.font.bold = True

# 正文（Normal）
body_run.font.name = 'Times New Roman'  # 西文字体
body_run.font.size = Pt(10.5)  # 五号 = 10.5pt
# 东亚字体 = 宋体
rFonts.set(qn('w:eastAsia'), '宋体')

# 表格内容
table_run.font.name = 'Times New Roman'
table_run.font.size = Pt(10.5)
rFonts.set(qn('w:eastAsia'), '宋体')

# 表格表头（加粗+白字+深蓝底）
table_header_run.font.name = '微软雅黑'
table_header_run.font.size = Pt(10.5)
table_header_run.font.bold = True
table_header_run.font.color.rgb = RGBColor(255, 255, 255)  # 白色
table_header_cell.shading.fill = '2F5496'  # 深蓝背景
```

### 字号对照表

| Word字号名称 | 对应Pt值 | 用途 |
|-------------|---------|------|
| 小二 | 18pt | 一级标题（Heading 1） |
| 三号 | 16pt | 二级标题（Heading 2） |
| 四号 | 14pt | 三级标题（Heading 3） |
| 小四 | 12pt | 四级标题（Heading 4） |
| 五号 | 10.5pt | 正文、表格内容 |

### 各元素字体设置一览

| 元素 | 中文字体 | 西文字体 | 字号 | 效果 | 颜色 |
|------|---------|---------|------|------|------|
| 一级标题 | 微软雅黑 | Times New Roman | 小二(18pt) | 加粗 | 黑色 |
| 二级标题 | 微软雅黑 | Times New Roman | 三号(16pt) | 加粗 | 黑色 |
| 三级标题 | 微软雅黑 | Times New Roman | 四号(14pt) | 加粗 | 黑色 |
| 四级标题 | 微软雅黑 | Times New Roman | 小四(12pt) | 加粗 | 黑色 |
| 正文 | 宋体 | Times New Roman | 五号(10.5pt) | 常规 | 黑色 |
| 表格内容 | 宋体 | Times New Roman | 五号(10.5pt) | 常规 | 黑色 |
| 表格表头 | 微软雅黑 | Times New Roman | 五号(10.5pt) | 加粗 | 白色 |
| 表格表头背景 | — | — | — | — | 深蓝(#2F5496) |

### 关键提醒

1. **必须显式设置每个run的字体**：不能依赖paragraph.style或document.default_style
2. **东亚字体必须单独设置**：中文字符使用`w:eastAsia`属性，西文字符使用`w:ascii`属性
3. **表格表头必须有背景色**：深蓝#2F5496 + 白色文字
4. **表格数据行交替背景**：白色 / 浅灰#F2F2F2
5. **表格边框**：灰色#D9D9D9，1pt

### 页面设置

- A4纸张（21cm × 29.7cm）
- 上下边距2.54cm，左右边距3.17cm
- **不添加页眉、页脚**

### 分页符规范（强制执行）

Word生成时通过python-docx插入分页符（Page Break）。**禁止**在Markdown中使用HTML分页标记 `<div style="page-break-after: always;"></div>`。

**只在以下两个位置插入分页**：
1. **标题页后**（标题页独占一页）
2. **参考资料章节前**（参考资料从新的一页开始）

**不在以下位置插入分页**：
- ❌ "六、下一步行动"前（应紧跟"五、商务报价"）
- ❌ 各章节之间（自然连续排版）

### 大纲

报告的大纲由Heading层级自动生成，**不单独生成目录页**。Word文档的标题层级（H1/H2/H3/H4）即构成大纲结构。

### 参考资料章节格式

- **参考资料章节必须从新的一页开始**
- 参考资料标题使用一级标题样式（微软雅黑 小二 18pt 加粗）
- 每条参考资料单独一行，格式 `[n] 来源描述 URL`

### 标题页格式（独占一页）

严格按用户偏好设置：

- **第一行**：客户全称，独占一行（居中，微软雅黑 22pt 加粗），段前间距 `space_before = Cm(8.0)`，使客户名距页眉约 1/3 页高。
- **第二行**：报告类型，居中（微软雅黑 16pt 加粗），紧跟客户名不再额外加间距，固定为“金蝶星瀚系统升级解决方案报告”或“金蝶星瀚系统升级立项报告”。
- **编制信息**：相对报告类型再下推 `space_before = Cm(9.0)`，位于页面约 2/3 处，包含编制单位和编制日期。
- 标题页后插入分页符，确保独占一整页。

**Markdown 生成约定**（供 Markdown → docx 转换器识别）：

```markdown
# 深圳市XX新能源科技有限公司（示例）
#!SUBTITLE 金蝶星瀚系统升级解决方案报告



**编制单位**：金蝶软件（中国）有限公司
**编制日期**：2026年07月08日

\newpage
```

转换器处理规则：
1. 第 1 个 `# ` 作为客户名称，单独居中段落（微软雅黑 22pt 加粗），设置 `space_before = Cm(8.0)`。
2. `#!SUBTITLE ` 行作为报告类型，单独居中段落（微软雅黑 16pt 加粗），不额外加段前间距。
3. 标题页上第一个以 `**` 开头的正文行视为编制信息首行，设置 `space_before = Cm(9.0)`，将其下推到页面约 2/3 处。
4. 编制信息后续行（如日期）正常紧跟，不再额外加间距。

### 项目组织架构图（Word 原生 SmartArt，嵌入式）

4.4 升级资源保障中的"项目组织架构"不再使用表格，而是插入 Word 原生可编辑 SmartArt（组织架构图），且必须为**嵌入式**（inline），不能与正文文字重叠。

**SmartArt 结构要求**：
- 顶层节点：项目领导小组（客户方：XXX / 金蝶方：XXX）
- 第二层：项目经理（客户方：XXX / 金蝶方：XXX）
- 项目经理下方三个**平级**功能组：财务组、供应链组、环境运维组
- 每个功能组下方为组内成员占位（可留空待填）

**SmartArt 节点添加常量（Word COM）**：
- `msoSmartArtNodeBelow = 5`：在下方添加子节点
- `msoSmartArtNodeAfter = 2`：在同级之后添加节点
- `msoSmartArtNodeTypeDefault = 1`：普通节点

**实现路径（强制执行）**：

1. **Word COM 生成内嵌 SmartArt 模板 docx**
   - 启动 Word，新建空白文档；
   - 获取组织架构图布局：`layout = word.SmartArtLayouts(96)`（本机验证索引为 96，对应 `orgChart1`）；
   - 使用浮动形状创建：`shape = doc.Shapes.AddSmartArt(layout, 0, 0, 520, 360)`；
   - 通过 `shape.SmartArt.AllNodes` 构建节点，用 `root.AddNode(5, 1)` 添加子节点、`root.AddNode(2, 1)` 添加同级节点；
   - **必须转换为嵌入式**：`shape.ConvertToInlineShape()`；
   - 保存为模板文件，如 `smartart_template.docx`，关闭 Word。

2. **解包模板，提取 SmartArt 资源**
   - 将 `smartart_template.docx` 解包为 OPC 包；
   - 复制整个 `word/diagrams/` 目录（含 `data1.xml`、`drawing1.xml`、`colors1.xml`、`quickStyle1.xml` 等）；
   - 记录 `word/_rels/document.xml.rels` 中 SmartArt 对应的 relationship IDs（`rId1` ~ `rId4`，类型依次为 `diagramData`、`diagramDrawing`、`diagramColors`、`diagramQuickStyle`）。

3. **将 SmartArt 注入目标 docx**
   - 打开目标 docx（由 python-docx 生成），同样解包为 OPC 包；
   - 将步骤 2 的 `word/diagrams/` 目录整体复制到目标包；
   - 在 `word/_rels/document.xml.rels` 中新增 relationship，记录新分配的 `rId` 值；
   - 在 `[Content_Types].xml` 中注册 diagrams 相关 Part 类型（如 `application/vnd.openxmlformats-officedocument.drawingml.diagramData+xml` 等）；
   - 定位 `word/document.xml` 中包含"项目组织架构"文本的段落，在其后新建一个空段落；
   - 从模板 `word/document.xml` 中拷贝 `<w:drawing>` 元素，将其内部 `r:dm`、`r:lo`、`r:qs`、`r:cs` 关系引用重映射为步骤 3 新增的目标 `rId`；
   - 将重映射后的 `<w:drawing>` 插入到新建段落中；
   - **强制校验 drawing 元素**：该 `<w:drawing>` 必须直接包含 `<wp:inline ...>`，**禁止**出现 `<wp:anchor ...>` 或任何 `wrap` 属性。

4. **重新打包并验证**
   - 重新压缩为目标 docx；
   - 用 Word COM 打开校验：`InlineShapes.Count == 1` 且 `Shapes.Count == 0`；
   - 如校验失败，必须重跑转换，不可直接交付。

**禁止**：
- ❌ 使用 `doc.InlineShapes.AddSmartArt(int, ...)` 直接传入整数布局索引（不同机器索引不一致，必须用 `SmartArtLayouts` 对象）；
- ❌ 不调用 `ConvertToInlineShape()`，导致 SmartArt 为浮动对象；
- ❌ 只复制 `word/diagrams/` 文件而不在 `document.xml` 中插入 `<w:drawing>`；
- ❌ 注入后出现 `<wp:anchor>` 或 `wrap` 属性。

### 输出文件名

生成的 Word 文档使用中文文件名：
- 解决方案报告：`金蝶星瀚系统升级解决方案报告.docx`
- 立项报告：`金蝶星瀚系统升级立项报告.docx`

### 禁止

- ❌ 依赖Word默认样式（等线/Calibri）
- ❌ 使用Pandoc直接转换后不做python-docx后处理（Pandoc无法控制中文字体）
- ❌ 只设置paragraph.style.font而不设置run.font
- ❌ 不设置w:eastAsia属性（中文字符会显示为宋体以外的字体）

---

## Word转换方式（纯python-docx直接生成）

**核心原则**：不经过pandoc，直接用python-docx的API创建完整Word文档。Agent将Markdown内容解析为结构化块后，逐块调用python-docx接口写入。

**参考实现框架**：

```python
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

def set_run_font(run, font_name='宋体', font_size=Pt(10.5), bold=False, color=RGBColor(0,0,0)):
    """设置run字体：中文字体通过w:eastAsia设置，西文通过w:ascii/w:hAnsi设置"""
    run.font.size = font_size
    run.font.bold = bold
    run.font.color.rgb = color
    run.font.name = 'Times New Roman'
    rPr = run._element.find(qn('w:rPr'))
    if rPr is None:
        rPr = OxmlElement('w:rPr')
        run._element.insert(0, rPr)
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rPr.insert(0, rFonts)
    rFonts.set(qn('w:eastAsia'), font_name)
    rFonts.set(qn('w:ascii'), 'Times New Roman')
    rFonts.set(qn('w:hAnsi'), 'Times New Roman')

def add_heading(doc, text, level=1):
    """添加标题。H1-H4全部左对齐。所有标题微软雅黑加粗。"""
    para = doc.add_heading(text, level=level)
    font_cfg = {
        1: ('微软雅黑', Pt(18)),  # 小二
        2: ('微软雅黑', Pt(16)),  # 三号
        3: ('微软雅黑', Pt(14)),  # 四号
        4: ('微软雅黑', Pt(12)),  # 小四
    }
    font_name, font_size = font_cfg.get(level, ('微软雅黑', Pt(12)))
    for run in para.runs:
        set_run_font(run, font_name, font_size, bold=True)
        # H4显式关闭斜体（python-docx默认Heading 4可能带斜体）
        if level == 4:
            run.font.italic = False
    para.alignment = WD_ALIGN_PARAGRAPH.LEFT
    return para

def add_paragraph(doc, text, bold=False):
    """添加正文段落。宋体五号，行距22pt。"""
    para = doc.add_paragraph()
    run = para.add_run(text)
    set_run_font(run, '宋体', Pt(10.5), bold=bold)
    para.paragraph_format.line_spacing = Pt(22)
    return para

def add_table(doc, headers, rows):
    """添加表格。表头深蓝背景(#2F5496)+白字加粗，数据行宋体五号。"""
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = 'Table Grid'
    # 表头
    for i, header in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = ''
        p = cell.paragraphs[0]
        run = p.add_run(header)
        set_run_font(run, '微软雅黑', Pt(10.5), bold=True, color=RGBColor(255,255,255))
        tcPr = cell._element.find(qn('w:tcPr'))
        if tcPr is None:
            tcPr = OxmlElement('w:tcPr')
            cell._element.insert(0, tcPr)
        shading = OxmlElement('w:shd')
        shading.set(qn('w:fill'), '2F5496')
        shading.set(qn('w:val'), 'clear')
        tcPr.append(shading)
    # 数据行
    for r_idx, row_data in enumerate(rows):
        for c_idx, cell_text in enumerate(row_data):
            cell = table.rows[r_idx + 1].cells[c_idx]
            cell.text = ''
            p = cell.paragraphs[0]
            run = p.add_run(str(cell_text))
            set_run_font(run, '宋体', Pt(10.5))
    return table

def add_page_break(doc):
    """添加分页符。只在两个位置使用：标题页后、参考资料前。"""
    para = doc.add_paragraph()
    run = para.add_run()
    br = OxmlElement('w:br')
    br.set(qn('w:type'), 'page')
    run._element.append(br)

def generate_docx(customer_name, content_blocks, output_path):
    """
    content_blocks: 列表，每项是字典：
    [
      {'type': 'title', 'text': '...'},
      {'type': 'heading2', 'text': '...'},
      {'type': 'heading3', 'text': '...'},
      {'type': 'heading4', 'text': '...'},
      {'type': 'paragraph', 'text': '...', 'bold': False},
      {'type': 'table', 'headers': [...], 'rows': [[...], ...]},
      {'type': 'page_break'},   # 仅用于标题页后和参考资料前
      ...
    ]
    """
    doc = Document()
    
    # 页面设置
    section = doc.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(3.17)
    section.right_margin = Cm(3.17)
    
    # 逐块写入
    for block in content_blocks:
        t = block['type']
        if t == 'title':
            add_heading(doc, block['text'], 1)
        elif t == 'heading2':
            add_heading(doc, block['text'], 2)
        elif t == 'heading3':
            add_heading(doc, block['text'], 3)
        elif t == 'heading4':
            add_heading(doc, block['text'], 4)
        elif t == 'paragraph':
            add_paragraph(doc, block['text'], bold=block.get('bold', False))
        elif t == 'table':
            add_table(doc, block['headers'], block['rows'])
        elif t == 'page_break':
            add_page_break(doc)
    
    doc.save(output_path)
    return output_path
```

```python
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

def set_run_font(run, font_name='宋体', font_size=Pt(10.5), bold=False, color=RGBColor(0,0,0)):
    """设置run字体：中文字体通过w:eastAsia设置"""
    run.font.size = font_size
    run.font.bold = bold
    run.font.color.rgb = color
    run.font.name = 'Times New Roman'
    rPr = run._element.find(qn('w:rPr'))
    if rPr is None:
        rPr = OxmlElement('w:rPr')
        run._element.insert(0, rPr)
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rPr.insert(0, rFonts)
    rFonts.set(qn('w:eastAsia'), font_name)
    rFonts.set(qn('w:ascii'), 'Times New Roman')
    rFonts.set(qn('w:hAnsi'), 'Times New Roman')

def add_heading(doc, text, level=1):
    """添加标题，返回paragraph"""
    para = doc.add_heading(text, level=level)
    font_cfg = {
        1: ('微软雅黑', Pt(18)),  # 小二
        2: ('微软雅黑', Pt(16)),  # 三号
        3: ('微软雅黑', Pt(14)),  # 四号
        4: ('微软雅黑', Pt(12)),  # 小四
    }
    font_name, font_size = font_cfg.get(level, ('微软雅黑', Pt(12)))
    for run in para.runs:
        set_run_font(run, font_name, font_size, bold=True)
        # H4显式关闭斜体（python-docx默认Heading 4可能带斜体）
        if level == 4:
            run.font.italic = False
    para.alignment = WD_ALIGN_PARAGRAPH.LEFT
    return para

def add_paragraph(doc, text, bold=False, first_line_indent=True):
    """添加正文段落"""
    para = doc.add_paragraph()
    run = para.add_run(text)
    set_run_font(run, '宋体', Pt(10.5), bold=bold)
    if first_line_indent:
        para.paragraph_format.first_line_indent = Cm(0.74)
    para.paragraph_format.line_spacing = Pt(22)
    return para

def add_table(doc, headers, rows):
    """添加表格，表头深蓝背景白字"""
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = 'Table Grid'
    # 表头
    for i, header in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = ''
        p = cell.paragraphs[0]
        run = p.add_run(header)
        set_run_font(run, '微软雅黑', Pt(10.5), bold=True, color=RGBColor(255,255,255))
        # 深蓝背景
        tcPr = cell._element.find(qn('w:tcPr'))
        if tcPr is None:
            tcPr = OxmlElement('w:tcPr')
            cell._element.insert(0, tcPr)
        shading = OxmlElement('w:shd')
        shading.set(qn('w:fill'), '2F5496')
        shading.set(qn('w:val'), 'clear')
        tcPr.append(shading)
    # 数据行
    for r_idx, row_data in enumerate(rows):
        for c_idx, cell_text in enumerate(row_data):
            cell = table.rows[r_idx + 1].cells[c_idx]
            cell.text = ''
            p = cell.paragraphs[0]
            run = p.add_run(str(cell_text))
            set_run_font(run, '宋体', Pt(10.5))
    return table

def add_numbered_list(doc, items, restart=True):
    """添加编号列表。restart=True时每章重新开始编号（从1开始）。
    
    关键：Word中编号列表默认跨段落连续，必须通过numPr显式设置restart。
    """
    for i, item in enumerate(items):
        para = doc.add_paragraph()
        run = para.add_run(item)
        set_run_font(run, '宋体', Pt(10.5))
        para.paragraph_format.line_spacing = Pt(22)
        # 设置编号格式
        pPr = para._element.find(qn('w:pPr'))
        if pPr is None:
            pPr = OxmlElement('w:pPr')
            para._element.insert(0, pPr)
        numPr = OxmlElement('w:numPr')
        ilvl = OxmlElement('w:ilvl')
        ilvl.set(qn('w:val'), '0')
        numPr.append(ilvl)
        numId = OxmlElement('w:numId')
        numId.set(qn('w:val'), '1')  # 使用文档的编号定义1
        numPr.append(numId)
        if restart and i == 0:
            # 第一个条目设置restart，确保从1开始
            ins = OxmlElement('w:ins')
            ins.set(qn('w:val'), '1')
            numPr.append(ins)
        pPr.append(numPr)
    return

def add_page_break(doc):
    """添加分页符"""
    para = doc.add_paragraph()
    run = para.add_run()
    br = OxmlElement('w:br')
    br.set(qn('w:type'), 'page')
    run._element.append(br)

# ========== 主流程 ==========
def generate_docx(customer_name, content_blocks, output_path):
    """
    content_blocks: 列表，每项是字典，如：
    [
      {'type': 'title', 'text': '...'},
      {'type': 'heading1', 'text': '...'},
      {'type': 'heading2', 'text': '...'},
      {'type': 'heading3', 'text': '...'},
      {'type': 'paragraph', 'text': '...', 'bold': False},
      {'type': 'table', 'headers': [...], 'rows': [[...], ...]},
      {'type': 'numbered_list', 'items': ['item1', 'item2', ...], 'restart': True},
      {'type': 'page_break'},
      {'type': 'toc'},
      ...
    ]
    """
    doc = Document()
    
    # 页面设置
    section = doc.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(3.17)
    section.right_margin = Cm(3.17)
    
    # 逐块写入
    for block in content_blocks:
        t = block['type']
        if t == 'title':
            add_heading(doc, block['text'], 1)
        elif t == 'heading1':
            add_heading(doc, block['text'], 1)
        elif t == 'heading2':
            add_heading(doc, block['text'], 2)
        elif t == 'heading3':
            add_heading(doc, block['text'], 3)
        elif t == 'heading4':
            add_heading(doc, block['text'], 4)
        elif t == 'paragraph':
            add_paragraph(doc, block['text'], bold=block.get('bold', False))
        elif t == 'table':
            add_table(doc, block['headers'], block['rows'])
        elif t == 'page_break':
            add_page_break(doc)
    
    doc.save(output_path)
    return output_path
```

### Markdown → docx 渲染细节

Markdown 文本在写入 Word 之前，必须解析其中的**加粗标记**和**上标引用编号**，并通过 python-docx 的 Run 级属性精确还原，禁止以纯文本形式直接写入 Unicode 上标字符。

**1. 加粗标记 `**文本**`**

段落、列表项、表格单元格中的文本都需要按 `**...**` 切分，并为包裹内容创建 `bold=True` 的 Run。

```python
def add_formatted_runs(paragraph, text, base_font='宋体', base_size=Pt(10.5), color=RGBColor(0,0,0)):
    """解析 **bold** 和 Unicode 上标，将切分后的片段加入段落。"""
    import re
    # 先按 **bold** 切分
    parts = re.split(r'(\*\*.*?\*\*)', text)
    for part in parts:
        bold = False
        content = part
        if part.startswith('**') and part.endswith('**') and len(part) >= 4:
            bold = True
            content = part[2:-2]
        # 再按上标数字切分
        for seg, is_sup in split_superscript_segments(content):
            run = paragraph.add_run(seg)
            set_run_font(run, base_font, base_size, bold=bold, color=color)
            if is_sup:
                # 将上标数字转为 Word 原生 superscript
                run.font.superscript = True
```

**2. Unicode 上标 → Word 原生 superscript**

正文中相邻引用使用 Unicode 上标数字（如 `¹²`）表示，但在写入 Word 时必须转换为普通数字并设置 `w:vertAlign="superscript"`。

正确的 Unicode 上标数字映射表（供解析使用）：

| 数字 | Unicode | 代码点 |
|------|---------|--------|
| 0 | `⁰` | U+2070 |
| 1 | `¹` | U+00B9 |
| 2 | `²` | U+00B2 |
| 3 | `³` | U+00B3 |
| 4 | `⁴` | U+2074 |
| 5 | `⁵` | U+2075 |
| 6 | `⁶` | U+2076 |
| 7 | `⁷` | U+2077 |
| 8 | `⁸` | U+2078 |
| 9 | `⁹` | U+2079 |

**禁止使用** `chr(0x2070 + digit)` 生成上标，因为该公式对 1、2、3 会生成错误字符。

```python
SUP_MAP = {
    '0': '\u2070', '1': '\u00b9', '2': '\u00b2', '3': '\u00b3',
    '4': '\u2074', '5': '\u2075', '6': '\u2076', '7': '\u2077',
    '8': '\u2078', '9': '\u2079',
}

def to_superscript(num: int) -> str:
    return ''.join(SUP_MAP[d] for d in str(num))
```

解析时，按连续的上标 Unicode 字符切分，并将每个上标段还原为普通数字字符串，同时标记 `is_sup=True`。

```python
def split_superscript_segments(text):
    """将文本切分为 (segment, is_superscript) 列表。"""
    import re
    # 上标 Unicode 范围：U+00B9, U+00B2, U+00B3, U+2070-2079
    pattern = re.compile(r'[\u00B9\u00B2\u00B3\u2070-\u2079]+')
    result = []
    last = 0
    for m in pattern.finditer(text):
        if m.start() > last:
            result.append((text[last:m.start()], False))
        sup_chars = m.group()
        # 转回普通数字
        reverse_map = {v: k for k, v in SUP_MAP.items()}
        normal_digits = ''.join(reverse_map[ch] for ch in sup_chars)
        result.append((normal_digits, True))
        last = m.end()
    if last < len(text):
        result.append((text[last:], False))
    return result
```

**3. 相邻引用分隔（U+200C）**

当两个引用编号直接相邻时（如 `¹²` 表示引用 [1] 和 [2]），必须在它们之间插入 **U+200C 零宽非连接符**（zero-width non-joiner），避免解析时被误读为一个两位数的引用 [12]。

```python
class CitationRegistry:
    def __init__(self):
        self._refs = []
        self.last_cite = None

    def cite(self, index: int) -> str:
        """返回用于 Markdown 的上标引用字符串。"""
        prefix = '\u200c' if self.last_cite is not None else ''
        self.last_cite = index
        return prefix + to_superscript(index)

    def reset_adjacency(self):
        """在追加新段落或新表格前调用，避免跨块错误连接。"""
        self.last_cite = None
```

**4. 表格单元格格式化**

表格单元格必须复用 `add_formatted_runs`，确保单元格内的 `**加粗**` 和上标引用都能正确渲染。

```python
def add_docx_table(doc, headers, rows):
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = 'Table Grid'
    # 表头
    for i, header in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = ''
        p = cell.paragraphs[0]
        add_formatted_runs(p, header, base_font='微软雅黑', base_size=Pt(10.5),
                           color=RGBColor(255,255,255))
        # 设置深蓝背景...
    # 数据行
    for r_idx, row_data in enumerate(rows):
        for c_idx, cell_text in enumerate(row_data):
            cell = table.rows[r_idx + 1].cells[c_idx]
            cell.text = ''
            p = cell.paragraphs[0]
            add_formatted_runs(p, str(cell_text), base_font='宋体', base_size=Pt(10.5))
    return table
```

**校验规则**：
- 生成完成后，用 `lxml` 检查 `word/document.xml`，所有引用编号对应的 Run 必须包含 `<w:vertAlign w:val="superscript"/>`；
- 禁止在 docx 中出现未解析的 `**` 标记或 HTML 注释；
- 引用编号在正文中出现的最大值必须等于参考资料列表的条目数。

**核心原则**：所有Word文档必须通过python-docx显式设置字体，确保中文字体（微软雅黑/宋体）正确渲染。**不依赖pandoc**。
