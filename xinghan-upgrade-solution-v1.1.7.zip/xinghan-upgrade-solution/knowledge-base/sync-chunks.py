#!/usr/bin/env python3
"""
知识库语义分块同步工具
支持：A-全量重建 / B-增量检测
"""

import os
import sys
import json
import hashlib
import re
import glob
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional

# 配置
KB_ROOT = Path(__file__).parent.parent / "knowledge-base"
CHUNKS_DIR = KB_ROOT / ".chunks"
INDEX_FILE = KB_ROOT / "index.yaml"
CHUNK_INDEX = CHUNKS_DIR / "chunk-index.json"

# 分块参数
CHUNK_MAX_TOKENS = 1500  # 每个块最大token估算（中文约1token/字）
CHUNK_OVERLAP_LINES = 2    # 块间重叠行数


def file_hash(filepath: Path) -> str:
    """计算文件内容hash（用于增量检测）"""
    if not filepath.exists():
        return ""
    h = hashlib.md5()
    h.update(filepath.read_bytes())
    return h.hexdigest()


def chunk_hash(content: str) -> str:
    """计算chunk内容hash（作为chunk ID）"""
    h = hashlib.sha256()
    h.update(content.encode('utf-8'))
    return h.hexdigest()[:16]


def estimate_tokens(text: str) -> int:
    """估算token数量（中文粗略估算）"""
    # 中文约1字≈1token，英文按词
    cn_chars = len(re.findall(r'[\u4e00-\u9fff]', text))
    en_tokens = len(re.findall(r'[a-zA-Z]+', text))
    return cn_chars + en_tokens


def split_by_headers(content: str, source_file: str, doc_id: str) -> List[Dict[str, Any]]:
    """
    按Markdown标题层级分块
    策略：h2/h3 作为分块边界，每个块包含一个主题
    """
    lines = content.split('\n')
    chunks = []
    current_lines = []
    current_title = "__intro__"
    current_level = 0
    
    def flush_chunk():
        if current_lines:
            text = '\n'.join(current_lines).strip()
            if len(text) > 50:  # 过滤太短的碎片
                ch = chunk_hash(text)
                chunks.append({
                    "id": f"{doc_id}__{ch}",
                    "doc_id": doc_id,
                    "source_file": source_file,
                    "section_title": current_title,
                    "header_level": current_level,
                    "content": text,
                    "hash": ch,
                    "tokens": estimate_tokens(text),
                    "updated_at": datetime.now().isoformat()
                })
            current_lines.clear()
    
    for line in lines:
        # 检测标题
        m = re.match(r'^(#{2,4})\s+(.+)', line)
        if m:
            flush_chunk()
            current_level = len(m.group(1))
            current_title = m.group(2).strip()
            current_lines.append(line)
        else:
            current_lines.append(line)
    
    flush_chunk()
    return chunks


def split_large_chunk(chunk: Dict[str, Any], max_tokens: int = CHUNK_MAX_TOKENS) -> List[Dict[str, Any]]:
    """
    如果块太大，按段落进一步切分
    保持标题上下文
    """
    if chunk["tokens"] <= max_tokens:
        return [chunk]
    
    lines = chunk["content"].split('\n')
    sub_chunks = []
    current_lines = []
    current_tokens = 0
    part_num = 0
    
    # 保留标题行
    header_lines = []
    header_tokens = 0
    for line in lines:
        if re.match(r'^#{2,4}\s+', line):
            header_lines.append(line)
            header_tokens += estimate_tokens(line)
        else:
            break
    
    for line in lines[len(header_lines):]:
        line_tokens = estimate_tokens(line)
        if current_tokens + line_tokens > max_tokens and current_lines:
            text = '\n'.join(header_lines + current_lines).strip()
            ch = chunk_hash(text)
            sub_chunks.append({
                "id": f"{chunk['doc_id']}__{chunk['hash']}_p{part_num}",
                "doc_id": chunk["doc_id"],
                "source_file": chunk["source_file"],
                "section_title": f"{chunk['section_title']} (Part {part_num+1})",
                "header_level": chunk["header_level"],
                "content": text,
                "hash": ch,
                "tokens": estimate_tokens(text),
                "updated_at": chunk["updated_at"]
            })
            current_lines = []
            current_tokens = 0
            part_num += 1
        
        current_lines.append(line)
        current_tokens += line_tokens
    
    if current_lines:
        text = '\n'.join(header_lines + current_lines).strip()
        ch = chunk_hash(text)
        sub_chunks.append({
            "id": f"{chunk['doc_id']}__{chunk['hash']}_p{part_num}",
            "doc_id": chunk["doc_id"],
            "source_file": chunk["source_file"],
            "section_title": f"{chunk['section_title']} (Part {part_num+1})",
            "header_level": chunk["header_level"],
            "content": text,
            "hash": ch,
            "tokens": estimate_tokens(text),
            "updated_at": chunk["updated_at"]
        })
    
    return sub_chunks


def extract_frontmatter(content: str) -> tuple:
    """提取YAML frontmatter"""
    if content.startswith('---'):
        parts = content.split('---', 2)
        if len(parts) >= 3:
            return parts[1].strip(), parts[2].strip()
    return "", content


def chunk_file(md_file: Path, doc_id: str) -> List[Dict[str, Any]]:
    """对单个md文件进行分块"""
    content = md_file.read_text(encoding='utf-8')
    _, body = extract_frontmatter(content)
    
    raw_chunks = split_by_headers(body, str(md_file), doc_id)
    
    # 对过大的块进一步切分
    final_chunks = []
    for rc in raw_chunks:
        final_chunks.extend(split_large_chunk(rc))
    
    return final_chunks


def get_all_md_files() -> List[tuple]:
    """获取知识库中所有需要分块的md文件"""
    md_files = []
    refs_dir = KB_ROOT / "references"
    
    for md_file in refs_dir.rglob("*.md"):
        # 跳过summary文件和已生成的chunk文件
        if md_file.name == "summary.md" or ".chunks" in str(md_file):
            continue
        # 生成doc_id
        rel = md_file.relative_to(refs_dir)
        doc_id = str(rel).replace('/', '__').replace('.md', '')
        md_files.append((doc_id, md_file))
    
    return md_files


def load_chunk_index() -> Dict[str, Any]:
    """加载chunk索引"""
    if CHUNK_INDEX.exists():
        return json.loads(CHUNK_INDEX.read_text(encoding='utf-8'))
    return {
        "version": "1.0",
        "created_at": datetime.now().isoformat(),
        "last_sync_mode": None,
        "last_sync_at": None,
        "files": {},
        "chunks": {},
        "total_chunks": 0,
        "total_files": 0
    }


def save_chunk_index(index: Dict[str, Any]):
    """保存chunk索引"""
    CHUNKS_DIR.mkdir(parents=True, exist_ok=True)
    CHUNK_INDEX.write_text(json.dumps(index, ensure_ascii=False, indent=2), encoding='utf-8')


def save_chunk_file(chunk: Dict[str, Any]):
    """保存单个chunk到文件"""
    CHUNKS_DIR.mkdir(parents=True, exist_ok=True)
    # 清理id中不适合做文件名的字符
    safe_id = chunk['id'].replace('/', '_').replace('\\', '_')
    chunk_path = CHUNKS_DIR / f"{safe_id}.json"
    chunk_path.write_text(json.dumps(chunk, ensure_ascii=False, indent=2), encoding='utf-8')


def delete_chunk_file(chunk_id: str):
    """删除chunk文件"""
    safe_id = chunk_id.replace('/', '_').replace('\\', '_')
    chunk_path = CHUNKS_DIR / f"{safe_id}.json"
    if chunk_path.exists():
        chunk_path.unlink()


def sync_full_rebuild():
    """
    A模式：全量重建
    删除所有现有chunk，重新生成
    """
    print("🔄 [A模式] 全量重建中...")
    
    # 清空旧chunks
    if CHUNKS_DIR.exists():
        for f in CHUNKS_DIR.glob("*.json"):
            if f.name != "chunk-index.json":
                f.unlink()
    
    index = {
        "version": "1.0",
        "created_at": datetime.now().isoformat(),
        "last_sync_mode": "full",
        "last_sync_at": datetime.now().isoformat(),
        "files": {},
        "chunks": {},
        "total_chunks": 0,
        "total_files": 0
    }
    
    md_files = get_all_md_files()
    all_chunks = []
    
    for doc_id, md_file in md_files:
        print(f"  分块: {doc_id}")
        fhash = file_hash(md_file)
        chunks = chunk_file(md_file, doc_id)
        
        for ck in chunks:
            save_chunk_file(ck)
            all_chunks.append(ck)
            index["chunks"][ck["id"]] = {
                "hash": ck["hash"],
                "doc_id": doc_id,
                "section_title": ck["section_title"],
                "tokens": ck["tokens"]
            }
        
        index["files"][doc_id] = {
            "path": str(md_file),
            "file_hash": fhash,
            "chunk_count": len(chunks),
            "last_sync": datetime.now().isoformat()
        }
    
    index["total_chunks"] = len(all_chunks)
    index["total_files"] = len(md_files)
    save_chunk_index(index)
    
    print(f"✅ 全量重建完成: {len(md_files)} 个文件 → {len(all_chunks)} 个chunks")
    return index


def sync_incremental():
    """
    B模式：增量检测
    检测文件变动，只更新变更的文件对应的chunks
    """
    print("📝 [B模式] 增量检测中...")
    
    index = load_chunk_index()
    md_files = get_all_md_files()
    
    changed_files = []
    new_files = []
    unchanged_files = []
    
    current_doc_ids = set()
    
    for doc_id, md_file in md_files:
        current_doc_ids.add(doc_id)
        fhash = file_hash(md_file)
        
        if doc_id not in index["files"]:
            new_files.append((doc_id, md_file))
        elif index["files"][doc_id].get("file_hash") != fhash:
            changed_files.append((doc_id, md_file))
        else:
            unchanged_files.append((doc_id, md_file))
    
    # 检测被删除的文件
    deleted_doc_ids = set(index["files"].keys()) - current_doc_ids
    
    total_changes = 0
    
    # 处理删除的文件
    for doc_id in deleted_doc_ids:
        print(f"  🗑️ 删除: {doc_id}")
        # 删除该文件的所有chunks
        chunk_ids_to_delete = [cid for cid, info in index["chunks"].items() 
                               if info.get("doc_id") == doc_id]
        for cid in chunk_ids_to_delete:
            delete_chunk_file(cid)
            del index["chunks"][cid]
        del index["files"][doc_id]
        total_changes += 1
    
    # 处理变更和新增的文件
    for doc_id, md_file in changed_files + new_files:
        action = "变更" if doc_id in [x[0] for x in changed_files] else "新增"
        print(f"  🔄 {action}: {doc_id}")
        
        # 删除旧chunks（如果是变更）
        if doc_id in index["files"]:
            old_chunk_ids = [cid for cid, info in index["chunks"].items() 
                           if info.get("doc_id") == doc_id]
            for cid in old_chunk_ids:
                delete_chunk_file(cid)
                del index["chunks"][cid]
        
        # 生成新chunks
        fhash = file_hash(md_file)
        chunks = chunk_file(md_file, doc_id)
        
        for ck in chunks:
            save_chunk_file(ck)
            index["chunks"][ck["id"]] = {
                "hash": ck["hash"],
                "doc_id": doc_id,
                "section_title": ck["section_title"],
                "tokens": ck["tokens"]
            }
        
        index["files"][doc_id] = {
            "path": str(md_file),
            "file_hash": fhash,
            "chunk_count": len(chunks),
            "last_sync": datetime.now().isoformat()
        }
        total_changes += 1
    
    index["last_sync_mode"] = "incremental"
    index["last_sync_at"] = datetime.now().isoformat()
    index["total_chunks"] = len(index["chunks"])
    index["total_files"] = len(index["files"])
    save_chunk_index(index)
    
    print(f"✅ 增量同步完成:")
    print(f"   新增: {len(new_files)} 个")
    print(f"   变更: {len(changed_files)} 个")
    print(f"   删除: {len(deleted_doc_ids)} 个")
    print(f"   未变: {len(unchanged_files)} 个")
    print(f"   总计: {index['total_files']} 个文件 → {index['total_chunks']} 个chunks")
    
    return index


def print_status():
    """打印当前chunk状态"""
    index = load_chunk_index()
    
    print(f"\n📊 Chunk索引状态")
    print(f"   版本: {index.get('version', 'unknown')}")
    print(f"   创建: {index.get('created_at', 'N/A')}")
    print(f"   上次同步: {index.get('last_sync_at', 'N/A')} ({index.get('last_sync_mode', 'N/A')})")
    print(f"   文件数: {index.get('total_files', 0)}")
    print(f"   Chunk数: {index.get('total_chunks', 0)}")
    
    if index.get('files'):
        print(f"\n📁 已索引文件:")
        for doc_id, info in sorted(index['files'].items()):
            status = "✅" if Path(info['path']).exists() else "⚠️ MISSING"
            print(f"   {status} {doc_id} ({info.get('chunk_count', 0)} chunks)")


def main():
    if len(sys.argv) < 2:
        print("""
用法: python sync-chunks.py <command>

命令:
  full       A模式 - 全量重建 (删除所有chunks，重新生成)
  incr       B模式 - 增量检测 (只处理变更的文件)
  status     查看当前索引状态
  
示例:
  python sync-chunks.py full      # 全量重建
  python sync-chunks.py incr     # 增量检测
        """)
        return
    
    cmd = sys.argv[1]
    
    if cmd == "full":
        sync_full_rebuild()
    elif cmd == "incr":
        sync_incremental()
    elif cmd == "status":
        print_status()
    else:
        print(f"未知命令: {cmd}")
        print("可用: full, incr, status")


if __name__ == "__main__":
    main()
