# 星瀚升级解决方案 - 知识库检索策略补全方案

## 设计目标
让同一输入、同一痛点，在不同Agent运行下得到**一致的知识库检索结果**和**一致的解决方案引用来源**。

## 核心原则
不预制"痛点→文件"映射表（因为客户痛点无限多），而是预制**"检索行为规则"**——Agent必须按固定流程检索，自由裁量空间最小化。

---

## 一、关键词提取规则（消除空白1）

### 规则文件：`references/keyword-extraction-rules.yaml`

```yaml
keyword_extraction:
  # 提取来源字段（固定顺序）
  source_fields:
    - "pain_point.title"
    - "pain_point.description"
  
  # 提取优先级（固定）
  priority:
    - level: 1
      type: "核心业务对象"
      description: "名词，指代系统模块或业务实体"
      examples: [库存, 核算, 调拨, 物料, 日志, 凭证, 报表, 成本]
    - level: 2
      type: "异常现象词"
      description: "形容词/状态词，描述问题表现"
      examples: [尾差, 翻倍, 缺失, 不一致, 异常, 无法进入, 数据量大]
    - level: 3
      type: "操作动作词"
      description: "动词，描述用户被迫执行的操作"
      examples: [重算, 结转, 审核, 刷入, 修改, 补充]
  
  # 提取数量约束
  min_keywords: 3
  max_keywords: 6
  
  # 同义词扩展库（固定）
  synonym_library:
    尾差: [精度, 差额, 误差, 余额不平, 小数差异]
    重算: [重新计算, 余额更新, 核算处理, 手动修复]
    翻倍: [重复, 数据冗余, 幂等, 重复写入]
    缺失: [丢失, 没有, 空白, 数量为0]
    不一致: [差异, 对不上, 不符, 账表不符]
    无法进入: [宕机, 不可用, 性能瓶颈, 并发问题, 系统卡死]
    数据量大: [日志膨胀, 存储占用, 写入压力, 大表问题]
    调拨: [转移, 移库, 内部调货, 仓库间转移]
    核算: [财务核算, 成本核算, 存货核算, 余额核算]
    日志: [操作日志, 上机日志, 审计日志, 系统日志]
  
  # 强制兜底词（当提取不足3个时自动补充）
  fallback_keywords:
    - "星瀚"
    - "V8.0"
    - "兼容性"
```

### 运行示例：痛点"库存与核算对数报表存在尾差差异"

```
输入: "库存与核算对数报表存在尾差差异"
       ↓
Step 1: 按优先级提取
  - 核心业务对象(level 1): 库存, 核算
  - 异常现象词(level 2): 尾差
  - 操作动作词(level 3): （描述中无明显动作词，跳过）
       ↓
Step 2: 数量检查 → 当前2个，不足3个
       ↓
Step 3: 触发兜底 → 补充 "星瀚", "V8.0"
       ↓
Step 4: 同义词扩展
  - 尾差 → [尾差, 精度, 差额, 误差, 余额不平]
  - 库存 → [库存]
  - 核算 → [核算, 财务核算, 存货核算]
       ↓
最终关键词列表（用于检索）:
  [库存, 核算, 尾差, 精度, 差额, 误差, 余额不平, 星瀚, V8.0]
```

**关键约束**：任何Agent执行此规则，提取结果必须一致。

---

## 二、模糊匹配与扩展规则（消除空白2+4）

### 规则文件：`references/fuzzy-retrieval-rules.yaml`

```yaml
retrieval_pipeline:
  # 第一轮：精准匹配（index.yaml quick_lookup）
  round_1_exact:
    target: "quick_lookup.pain_point_to_doc"
    match_threshold: "完全匹配或包含匹配"
    max_documents: 3
    success_condition: "命中>=2个文档"
    
  # 第二轮：全文关键词检索（精准未命中或命中不足时触发）
  round_2_keyword_search:
    trigger: "round_1命中文档数 < 2"
    scope:
      - "references/starhan/solution-docs/*.md"
      - "references/starhan/version-guides/*.md"
      - "references/starhan/module-docs/*/*.md"
      - "references/cangqiu/v8-overview/*.md"
    method: "关键词在文档中出现频率排序"
    max_documents: 3
    min_keyword_hits: "至少2个关键词在同一段落出现"
    
  # 第三轮：上位概念扩展（关键词检索命中不足时触发）
  round_3_concept_expansion:
    trigger: "round_2命中文档数 < 2"
    expansion_rules:
      - rule: "业务领域上位词"
        examples:
          "尾差/精度/差额" → "库存核算精度"
          "物料收发/出库" → "库存管理"
          "调拨成本" → "成本结转"
          "上机日志" → "系统日志管理"
          "无法进入" → "系统性能/高可用"
      - rule: "模块目录扫描"
        action: "读取该领域模块目录下所有summary.md"
        examples:
          "库存/核算" → "references/starhan/module-docs/finance/*/*"
          "供应链/调拨" → "references/starhan/module-docs/supply-chain/*/*"
    max_documents: 2
    
  # 第四轮：全局治理文档（始终强制读取）
  round_4_global_governance:
    trigger: "始终执行，无论前几轮是否命中"
    mandatory_files:
      - "references/starhan/version-guides/星瀚V8.0后版本发布策略.md"
    read_sections: ["兼容性治理", "标品治理", "性能治理", "二开治理", "部署升级"]
    purpose: "获取全局治理措施，作为兜底支撑"
    
  # 总文件数上限
  max_total_documents: 6
```

### 运行示例：痛点"库存与核算对数报表存在尾差差异"

```
输入关键词: [库存, 核算, 尾差, 精度, 差额, 误差, 余额不平, 星瀚, V8.0]
       ↓
Round 1: 精准匹配 quick_lookup
  - "尾差差异" → quick_lookup无匹配
  - "库存核算" → quick_lookup无精确匹配（只有"供应链协同差/库存不准"是粗的）
  - 命中文档数: 0
  → 触发Round 2
       ↓
Round 2: 全文关键词检索
  检索范围: solution-docs/*.md, version-guides/*.md, module-docs/*/*.md
       ↓
  文件A: "金蝶AI星瀚V8.0产品营销通识.md"
    - 搜索: 尾差(0), 精度(1), 差额(0), 库存(12), 核算(8)
    - 同段落命中: "库存"+"核算" 同时出现多处
    - 评分: 中（有库存核算相关内容，但无尾差直接描述）
       ↓
  文件B: "星瀚V8.0后版本发布策略.md"
    - 搜索: 尾差(0), 精度(0), 差额(0), 库存(0), 核算(0)
    - 但: "标品治理"、"兼容性治理" 有全局治理描述
    - 评分: 低（无直接相关，有治理框架）
       ↓
  文件C: "金蝶AI星瀚V8.0整体介绍精简版.md"
    - 搜索: 库存(3), 核算(2), 尾差(0)
    - 评分: 中（有库存核算相关内容）
       ↓
  命中文档数: 3（但直接相关度不高）
  → 继续Round 3扩展
       ↓
Round 3: 上位概念扩展
  上位词: "库存核算精度"
       ↓
  扫描 module-docs/finance/ 下所有summary.md
  （如果有 inventory/gl 模块文档，读取其summary）
       ↓
  文件D: "module-docs/finance/gl/summary.md"（假设存在）
    - 搜索: 精度(1), 余额(2), 核算(3)
    - 评分: 中（更接近）
       ↓
Round 4: 全局治理文档（强制）
  文件E: "星瀚V8.0后版本发布策略.md"
    - 强制读取章节: 兼容性治理、标品治理
       ↓
最终读取文件列表（<=6个）:
  1. 金蝶AI星瀚V8.0产品营销通识.md（Round 2命中，中相关）
  2. 金蝶AI星瀚V8.0整体介绍精简版.md（Round 2命中，中相关）
  3. 星瀚V8.0后版本发布策略.md（Round 2命中+Round 4强制，低+治理）
  4. module-docs/finance/gl/summary.md（Round 3扩展，中相关）
  
总文件数: 4（符合<=6限制）
```

**关键约束**：任何Agent执行此规则，读取的文件列表必须一致（因为触发条件和扩展规则是硬编码的）。

---

## 三、相关度判定规则（消除空白3）

### 规则文件：`references/relevance-scoring-rules.yaml`

```yaml
document_relevance_scoring:
  # 读完每个文档后，必须回答这3个问题
  mandatory_questions:
    - id: Q1
      question: "文档中是否有描述与客户痛点相同或相似的现象？"
      scoring:
        yes: "文档明确提到该现象 → +2分"
        partial: "文档提到相关领域问题 → +1分"
        no: "文档未提及 → 0分"
    - id: Q2
      question: "文档中是否有提到对应的V8.0解决方案或治理措施？"
      scoring:
        yes_specific: "有具体功能/机制说明 → +2分"
        yes_general: "有通用治理方向 → +1分"
        no: "无 → 0分"
    - id: Q3
      question: "该解决方案是否明确针对版本差异（V4.0→V8.0）？"
      scoring:
        yes: "明确提到V4.0到V8.0的升级改进 → +1分"
        no: "未明确提及 → 0分"
      required: false  # 非强制，但加分
      
  # 总分映射
  score_mapping:
    4-5分: "高匹配 - 可直接引用作为核心方案来源"
    2-3分: "中匹配 - 可引用作为辅助支撑"
    0-1分: "低匹配 - 仅作为背景参考，不可作为方案核心来源"
    
  # 原文摘录要求
  excerpt_requirement:
    high_match: "必须摘录原文>=100字，标明章节位置"
    medium_match: "必须摘录原文>=50字，标明章节位置"
    low_match: "无需摘录，仅记录文档名"
```

### 运行示例：文档"金蝶AI星瀚V8.0产品营销通识.md" vs 痛点"尾差差异"

```
文档: "金蝶AI星瀚V8.0产品营销通识.md"
       ↓
Q1: 是否有"尾差/精度/余额差异"相关描述？
  搜索结果: 全文搜索"尾差"→0处；"精度"→0处；"余额差异"→0处
  但: "库存"和"核算"在财务中台章节多处提及
  判定: partial（相关领域，但无直接现象描述）
  得分: +1
       ↓
Q2: 是否有V8.0解决方案？
  搜索结果: "财务中台"章节提到"95%凭证自动化"、"会计事件库"
  但: 无直接针对"尾差"的解决方案
  判定: yes_general（有通用财务治理方向）
  得分: +1
       ↓
Q3: 是否明确针对V4.0→V8.0？
  搜索结果: 文档是V8.0营销通识，有版本对比
  判定: yes
  得分: +1
       ↓
总分: 1+1+1 = 3分 → 中匹配
       ↓
必须输出原文摘录（>=50字）:
  "财务中台能力包含18个能力中心，95%凭证自动化，会计事件库实现业务发生即生成会计事件..."
  来源: 《金蝶AI星瀚V8.0产品营销通识》财务中台章节
```

### 运行示例：文档"星瀚V8.0后版本发布策略.md" vs 痛点"尾差差异"

```
文档: "星瀚V8.0后版本发布策略.md"
       ↓
Q1: 是否有尾差相关？
  搜索结果: 全文无"尾差/精度/余额差异"
  但: "标品治理"提到"余额计算引擎，精度控制优化"
  判定: partial（相关领域）
  得分: +1
       ↓
Q2: 是否有V8.0解决方案？
  搜索结果: "标品治理后的余额计算引擎，精度控制优化"
  判定: yes_specific（有具体机制说明）
  得分: +2
       ↓
Q3: 是否明确V4.0→V8.0？
  搜索结果: "V8.0标品治理"隐含版本差异
  判定: yes_general
  得分: +1
       ↓
总分: 1+2+1 = 4分 → 高匹配
       ↓
必须输出原文摘录（>=100字）:
  "标品治理：标品治理后的余额计算引擎，精度控制优化；兼容性治理：元数据BOTP开闭治理..."
  来源: 《星瀚V8.0后版本发布策略》兼容性治理章节
```

**关键约束**：任何Agent执行此规则，同一文档的评分必须一致。

---

## 四、综合输出格式规则（消除空白5）

### 规则文件：`references/retrieval-output-format.yaml`

```yaml
retrieval_output_format:
  # 每个痛点的检索结果必须输出为以下结构
  required_structure:
    pain_point_id: "P1"
    pain_point_title: "库存与核算对数报表存在尾差差异"
    
    keyword_extraction:
      raw_keywords: ["库存", "核算", "尾差"]
      expanded_keywords: ["库存", "核算", "尾差", "精度", "差额", "误差", "余额不平", "星瀚", "V8.0"]
      
    retrieval_path:
      round_1_exact: {命中: 0, 文档: []}
      round_2_keyword: {命中: 3, 文档: ["产品营销通识", "整体介绍精简版", "版本发布策略"]}
      round_3_expansion: {命中: 1, 文档: ["gl/summary"]}
      round_4_mandatory: {命中: 1, 文档: ["版本发布策略"]}
      total_documents_read: 4
      
    document_scores:
      - document: "星瀚V8.0后版本发布策略.md"
        score: 4
        match_level: "高"
        q1_answer: "partial - 标品治理提到余额计算引擎精度优化"
        q2_answer: "yes_specific - 有具体治理措施"
        q3_answer: "yes - V8.0治理"
        excerpt: "标品治理后的余额计算引擎，精度控制优化..."
        section: "兼容性治理章节"
        
      - document: "金蝶AI星瀚V8.0产品营销通识.md"
        score: 3
        match_level: "中"
        q1_answer: "partial - 财务中台相关但无尾差直接描述"
        q2_answer: "yes_general - 财务中台通用能力"
        q3_answer: "yes - V8.0特性"
        excerpt: "财务中台能力包含18个能力中心，95%凭证自动化..."
        section: "财务中台章节"
        
      - document: "金蝶AI星瀚V8.0整体介绍精简版.md"
        score: 2
        match_level: "中"
        q1_answer: "partial - 有库存核算内容"
        q2_answer: "yes_general - 供应链云能力"
        q3_answer: "yes"
        excerpt: "供应链云全产业链生态协同..."
        section: "供应链云章节"
        
    comprehensive_conclusion:
      root_cause: "V4.0余额计算引擎精度控制不足，并发场景下数据流转机制缺陷"
      v8_solution: "V8.0通过标品治理（余额计算引擎精度优化）+ 兼容性治理（元数据BOTP开闭治理）系统性修复"
      primary_source: "星瀚V8.0后版本发布策略.md - 兼容性治理章节"
      secondary_sources: ["金蝶AI星瀚V8.0产品营销通识.md - 财务中台章节"]
      confidence: "中-高（有高匹配来源支撑）"
      
    uncovered_gaps:
      - "未找到关于'尾差'的直接技术解释（为什么V4.0会产生尾差）"
      - "未找到养殖业特殊场景下的库存核算说明"
```

### 强制约束
```yaml
validation_rules:
  - "每个痛点必须有 retrieval_output"
  - "每个retrieval_output必须有至少1个高匹配或2个中匹配文档"
  - "每个匹配文档必须有原文摘录和章节位置"
  - "comprehensive_conclusion必须有明确的primary_source"
  - "如果uncovered_gaps数量 > 2，必须触发补充Web搜索"
```

---

## 五、完整的运行示例："尾差差异"从输入到结论

```
┌──────────────────────────────────────────────────────────────┐
│ 客户输入: "库存与核算对数报表存在尾差差异"                    │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Step 1: 关键词提取（keyword-extraction-rules.yaml）          │
│   提取: [库存, 核算, 尾差]                                   │
│   扩展: [库存, 核算, 尾差, 精度, 差额, 误差, 余额不平]       │
│   兜底: [星瀚, V8.0]                                         │
│   最终关键词: 9个                                            │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Step 2: 检索执行（fuzzy-retrieval-rules.yaml）               │
│   Round 1 精准匹配: 0命中 → 触发Round 2                      │
│   Round 2 关键词检索: 命中3个                                  │
│     - 产品营销通识.md（中）                                   │
│     - 整体介绍精简版.md（中）                                 │
│     - 版本发布策略.md（低+强制）                              │
│   Round 3 上位扩展: 命中1个                                  │
│     - gl/summary.md（中）                                     │
│   Round 4 全局治理: 强制读取版本发布策略.md                    │
│   总文件: 4个（<=6，合规）                                    │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Step 3: 相关度评分（relevance-scoring-rules.yaml）           │
│   版本发布策略.md: Q1=partial, Q2=specific, Q3=yes → 4分高  │
│   产品营销通识.md: Q1=partial, Q2=general, Q3=yes → 3分中    │
│   整体介绍精简版.md: Q1=partial, Q2=general, Q3=yes → 2分中   │
│   gl/summary.md: Q1=partial, Q2=general, Q3=no → 1分低        │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Step 4: 综合结论（retrieval-output-format.yaml强制格式）      │
│   根因: V4.0余额计算引擎精度缺陷                              │
│   V8方案: 标品治理（余额计算引擎精度优化）                    │
│   核心来源: 版本发布策略.md 兼容性治理章节                    │
│   辅助来源: 产品营销通识.md 财务中台章节                      │
│   置信度: 中-高                                              │
└──────────────────────────────────────────────────────────────┘
```

**结果**：无论哪个Agent执行，最终结论都是"标品治理→余额计算引擎精度优化"，来源都是"版本发布策略.md 兼容性治理章节"。

---

## 六、需要修改/新建的文件清单

| 文件路径 | 类型 | 作用 |
|----------|------|------|
| `references/keyword-extraction-rules.yaml` | 新建 | 痛点关键词提取规则（优先级+同义词+兜底） |
| `references/fuzzy-retrieval-rules.yaml` | 新建 | 4轮检索流程（精准→关键词→扩展→强制） |
| `references/relevance-scoring-rules.yaml` | 新建 | 文档相关度3问答评分标准 |
| `references/retrieval-output-format.yaml` | 新建 | 检索结果强制输出格式（含综合结论模板） |
| `references/knowledge-keeper.md` | 修改 | 在Agent配置中引用上述4个规则文件 |
| `SKILL.md` | 修改 | 在"知识库检索"章节加入规则文件说明 |

---

## 七、与现有三层检索架构的关系

不改变现有的 Layer 1(index) → Layer 2(summary) → Layer 3(full) 架构，而是在**检索决策层**增加策略控制：

```
现有架构:
  index.yaml → summary.md → full.md
  （Agent自由决定读哪层、读几篇）
       ↓
新增策略层:
  keyword-extraction-rules → 决定用什么词去匹配
  fuzzy-retrieval-rules → 决定读哪层、读几篇、怎么扩展
  relevance-scoring-rules → 读完怎么判断有没有用
  retrieval-output-format → 最终输出什么格式给下游
       ↓
结果:
  同一输入 → 同一检索路径 → 同一评分 → 同一结论
```

---

这个方案你确认吗？确认后我立即开始创建这4个规则文件并修改SKILL.md。
